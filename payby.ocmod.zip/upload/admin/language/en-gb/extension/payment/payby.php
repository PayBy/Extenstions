<?php
// Heading
$_['heading_title']                 = 'PayBy';

// Text
$_['text_extension']                = 'Extensions';
$_['text_success']                  = 'Success: You have modified PayBy account details!';
$_['text_edit']                     = 'Edit PayBy Pay';
$_['text_payby']                    = '<a target="_BLANK" href="https://www.payby.com"><img src="view/image/payment/payby.png" alt="PayBy Website" title="PayBy Website" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_live']                     = 'Live';
$_['text_sandbox']                  = 'Sandbox';

// Entry
$_['entry_partner_id']              = 'Partner Id';
$_['entry_merchant_private_key']    = 'Merchant Private Key';
$_['entry_payby_public_key']        = 'PayBy Public Key';
$_['entry_completed_order_status']  = 'Completed Order Status';
$_['entry_run_mode']                = 'Run Mode';
$_['entry_status']                  = 'Status';
$_['entry_sort_order']              = 'Sort Order';
$_['entry_order_id_prefix']         = 'PayBy Payment OrderNo Prefix';
$_['entry_order_expire_seconds']    = 'PayBy Payment Expire Seconds';
$_['entry_currency_setted']         = 'Already SET Currency(AED)';

// Help
$_['help_partner_id']               = 'Your Parnter Id';
$_['help_merchant_private_key']     = 'Your Merchant Private Key';
$_['help_payby_public_key']         = 'Your PayBy Public Key';
$_['help_completed_order_status']   = 'Change your order status when payment completed';
$_['help_run_mode']                 = 'Change to Live Mode in your Production Environment';

$_['help_payby_setup']              = '<a target="_blank" href="https://www.payby.com/">Click here</a> to learn how to set up Payby account.';


// Error
$_['error_permission']              = 'Warning: You do not have permission to modify payment PayBy!';
$_['error_partner_id']              = 'Partner Id required!';
$_['error_merchant_private_key']    = 'Merchant Private Key required!';
$_['error_payby_public_key']        = 'PayBy Public Key required!';
$_['error_completed_order_status']  = 'Completed Order Status required!';
$_['error_order_id_prefix']         = 'PayBy Payment OrderNo Prefix required';
$_['error_order_expire_seconds']    = 'PayBy Payment Expire Seconds required';
$_['error_currency_setted']         = 'Make Sure Currency - AED is set';
