<?php
class ControllerExtensionPaymentPayby extends Controller
{
    private $error = array();

    private $paramKeys = [
        'payment_payby_partner_id',
        'payment_payby_merchant_private_key',
        'payment_payby_payby_public_key',
        'payment_payby_completed_order_status_id',
        'payment_payby_run_mode',
        'payment_payby_status',
        'payment_payby_sort_order',
        'payment_payby_order_id_prefix',
        #'payment_payby_order_expire_seconds',
        'payment_payby_currency_setted',
    ];

    public function index()
    {

        $this->load->language('extension/payment/payby');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('setting/setting');

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            $this->model_setting_setting->editSetting('payment_payby', $this->request->post);

            $this->session->data['success'] = $this->language->get('text_success');

            $this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true));
        }

        foreach ($this->error as $key => $value) {
            $data['error_'.$key] = $value;
        }

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true),
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true),
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/payment/payby', 'user_token=' . $this->session->data['user_token'], true),
        );

        $data['action'] = $this->url->link('extension/payment/payby', 'user_token=' . $this->session->data['user_token'], true);

        $data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true);

        $data = $this->setData($data);

        $this->load->model('localisation/order_status');
        $data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/payment/payby', $data));
    }

    private function validate()
    {
        $this->error = array(
            'warning'=> '',
            'entry_partner_id'=> '',
            'entry_merchant_private_key'=> '',
            'entry_payby_public_key'=> '',
            'entry_completed_order_status_id'=> '',

            'entry_payment_payby_order_id_prefix'=> '',
            'entry_payment_payby_order_expire_seconds'=> '',
            'entry_payment_payby_currency_setted'=> '',
        );

        $rtn = true;

        if (!$this->user->hasPermission('modify', 'extension/payment/payby')) {
            $this->error['warning'] = $this->language->get('error_permission');
            $rtn = false;
        }

        if (!$this->request->post['payment_payby_partner_id']) {
            $this->error['entry_partner_id'] = $this->language->get('error_partner_id');
            $rtn = false;
        }

        if (!$this->request->post['payment_payby_merchant_private_key']) {
            $this->error['entry_merchant_private_key'] = $this->language->get('error_merchant_private_key');
            $rtn = false;
        }

        if (!$this->request->post['payment_payby_payby_public_key']) {
            $this->error['entry_payby_public_key'] = $this->language->get('error_payby_public_key');
            $rtn = false;
        }

        if (!$this->request->post['payment_payby_completed_order_status_id']) {
            $this->error['entry_completed_order_status_id'] = $this->language->get('error_completed_order_status_id');
            $rtn = false;
        }


        if (!$this->request->post['payment_payby_order_id_prefix']) {
            $this->error['entry_order_id_prefix'] = $this->language->get('error_order_id_prefix');
            $rtn = false;
        }
        /*
        if (!$this->request->post['payment_payby_order_expire_seconds'] || intval($this->request->post['payment_payby_order_expire_seconds']) < 0 ) {
            $this->error['entry_order_expire_seconds'] = $this->language->get('error_order_expire_seconds');
            $rtn = false;
        }
        */

        if (!$this->request->post['payment_payby_currency_setted']) {
            $this->error['entry_currency_setted'] = $this->language->get('error_currency_setted');
            $rtn = false;
        }

        return $rtn;
    }

    public function setData($data)
    {
        foreach ($this->paramKeys as $key) {
            $data[$key] = isset($this->request->post[$key]) ? $this->request->post[$key] : $this->config->get($key);
        }
        return $data;
    }
}
