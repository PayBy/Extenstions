<?php
$_['text_title']                = '<img src="catalog/view/theme/default/image/payby/payby.png" alt="PayBy" title="PayBy" style="border: 1px solid #EEEEEE;height:25px;" />';


$_['error_currency_set']        = 'Not Set Currency - AED';
$_['error_order']               = 'Missed Order';
$_['error_paypage']             = 'Pay By System error';
