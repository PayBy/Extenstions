<?php
class ControllerExtensionPaymentPayby extends Controller {

    public function index() {
        $dara = array();
        $data['button_confirm'] = $this->language->get('button_confirm');
        $data['order_id'] = $this->session->data['order_id'];

        return $this->load->view('extension/payment/payby_0_9_0', $data);
    }

    public function confirm() {
        $this->load->language('extension/payment/payby');
        $this->load->model('checkout/order');

        $dara = array('tokenUrl'=>'','error_msg'=>'');

        $order_id = @$this->request->get['order_id'];
        if (@$order_id == '') {
            $data['error_msg'] = $this->language->get('error_order');

            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode($data));
            return;
        }

        $order_info = $this->model_checkout_order->getOrder($order_id);
        if(!$order_info){

            $data['error_msg'] = $this->language->get('error_order');

            $this->response->addHeader('Content-Type: application/json');
            $this->response->setOutput(json_encode($data));
            return;
        }

        require_once(DIR_SYSTEM . 'library/payby/init.php');

        $content_language = 'en';
        $sign_type = 'RSA2';
        $log_switch = false;
        $currency_code = "AED";

        $sim_gateway_host = "https://uat.test2pay.com";
        $live_gateway_host = "https://api.payby.com";

        $gateway_path = array(
            'placeOrder' => "/sgs/api/acquire2/placeOrder",
            'cancelOrder' => "/sgs/api/acquire2/cancelOrder",
            'getOrder' => "/sgs/api/acquire2/getOrder",

            'refundOrder' => "/sgs/api/acquire2/refund/placeOrder",
            'refundGetOrder' => "/sgs/api/acquire2/refund/getOrder",
        );

        $config = array (
            'content_language'      => $content_language,
            'partner_id'            => $this->config->get('payment_payby_partner_id'),
            'merchant_private_key'  => $this->config->get('payment_payby_merchant_private_key'),
            'payby_public_key'      => $this->config->get('payment_payby_payby_public_key'),
            'notify_url'            => $this->url->link('extension/payment/payby/callback', '', true),
            'redirect_url'          => $this->url->link('checkout/success', '', true),
            'sign_type'             => $sign_type,
            'gateway_host'          => $this->config->get('payment_payby_run_mode') == "sandbox" ? $sim_gateway_host : $live_gateway_host,
            'gateway_path'          => $gateway_path,
            'log_switch'            => $log_switch,
        );

        $builder = new PayPageBuilder($config);
        $builder->setRequestApi('placeOrder');
        $builder->setRequestTime(time()*1000);

        $tokenUrl = "";
        $error_msg = "";

        if($this->currency->has($currency_code)){

            $totalAmount = trim($this->currency->format($order_info['total'], $currency_code, '', false));

            $bz = array(
                'merchantOrderNo'   => $this->config->get('payment_payby_order_id_prefix').$order_id,
                'subject'           => trim($this->config->get('config_name')),
                'totalAmount'       => array(
                                            "currency"=> $currency_code,
                                            "amount"=> $totalAmount,
                                        ),
                #'expiredTime'=>(time()+$this->config->get('payment_payby_order_expire_seconds'))*1000,
                'payeeMid'=>$config['partner_id'],
                'paySceneCode'=>'PAYPAGE',

                'paySceneParams'=>array('redirectUrl'=>$config['redirect_url']),
                'notifyUrl'=>$config['notify_url'],
                #'accessoryContent'=>array(),
            );

            $builder->setBizContentarr($bz);

            $builder->generateSign();

            $payPage = new PbPayPage();

            $result=$payPage->request($builder);

            if(@$result['body']['interActionParams']['tokenUrl'] != ""){
                $tokenUrl = @$result['body']['interActionParams']['tokenUrl'];
            }
            else{
                $error_msg = $this->language->get('error_paypage');
            }

        }
        else{
            $error_msg = $this->language->get('error_currency_set');
        }

        $data['tokenUrl'] = $tokenUrl;
        $data['error_msg'] = $error_msg;

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($data));
    }

    public function callback() {
        require_once(DIR_SYSTEM . 'library/payby/init.php');

        $sign_type = 'RSA2';
        $log_switch = false;

        $config = array (
            'payby_public_key'      => $this->config->get('payment_payby_payby_public_key'),
            'sign_type'             => $sign_type,
            'log_switch'            => $log_switch,
        );

        $body = @file_get_contents('php://input');

        $sign = $_SERVER['HTTP_SIGN'];

        $builder = new PayPageBuilder($config);

        if( $builder->verify($body, $sign) )
        {
            $body = json_decode($body, true);
            $merchantOrderNo = $body['acquireOrder']['merchantOrderNo'];
            $status = $body['acquireOrder']['status'];

            if("PAID_SUCCESS" == $status || "SETTLED" == $status)
            {
                $order_id = substr($merchantOrderNo, strlen($this->config->get('payment_payby_order_id_prefix')));

                $this->load->model('checkout/order');
                $this->model_checkout_order->addOrderHistory($order_id, $this->config->get('payment_payby_completed_order_status_id'));

                echo "SUCCESS";
                exit;
            }

        }

        echo "FAIL";
        exit;
    }
}