<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
  
 * @category  payment
 * @package   payby

 * @copyright  2020
 * @license      Commercial License 
 * @version   2.0.0 
 */
namespace PayBy\Payment\Setup;

use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Customer\Setup\CustomerSetupFactory;

/**
 * @codeCoverageIgnore
 */
class InstallData implements InstallDataInterface
{
	/**
	 * @var CustomerSetupFactory
	 */
	protected $_customerSetupFactory;

	/**
	 * @param CustomerSetupFactory $customerSetupFactory
	 */
	public function __construct(CustomerSetupFactory $customerSetupFactory)
	{
		$this->_customerSetupFactory = $customerSetupFactory;
	}

	/**
	 * {@inheritdoc}
	 */
	public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
	{
		// prepare database for install
		$setup->startSetup();

	  

		/**
		 * Empty log file.
		 */
		$logFileName = BP . '/var/log/payby.log';
		if(file_exists($logFileName)) {
			$f = fopen($logFileName, 'w'); // just for emptying module log file
			fclose($f);
		}

		// prepare database after install
		$setup->endSetup();
	}
}
