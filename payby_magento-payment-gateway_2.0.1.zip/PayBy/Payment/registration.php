<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
 *
 * @category  payment
 * @package   payby  
 * @copyright PayBy.com
 * @version   2.0.0 
 */

\Magento\Framework\Component\ComponentRegistrar::register(
	\Magento\Framework\Component\ComponentRegistrar::MODULE,
	'PayBy_Payment',
	__DIR__
);