<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
 *
 * @category  payment
 * @package   payby  
 * @copyright PayBy.com
 * @version   2.0.0 
 */
namespace PayBy\Payment\Controller;

abstract class Payment extends \Magento\Framework\App\Action\Action
{
	/**
	 * @var \PayBy\Payment\Helper\Data
	 */
	protected $_dataHelper;

	/**
	 * @var \PayBy\Payment\Helper\Payment
	 */
	protected $_paymentHelper;

	/**
	 * @var \Magento\Store\Model\StoreManagerInterface
	 */
	protected $_storeManager;

	/**
	 * @var \Magento\Quote\Api\CartRepositoryInterface
	 */
	protected $_quoteRepository;

	/**
	 * @param \Magento\Framework\App\Action\Context $context
	 * @param \Magento\Store\Model\StoreManagerInterface $storeManager
	 * @param \PayBy\Payment\Helper\Data $dataHelper
	 * @param \PayBy\Payment\Helper\Payment $paymentHelper
	 * @param \Magento\Quote\Api\CartRepositoryInterface $quoteRepository
	 */
	public function __construct(
			\Magento\Framework\App\Action\Context $context,
			\Magento\Store\Model\StoreManagerInterface $storeManager,
			\PayBy\Payment\Helper\Data $dataHelper,
			\PayBy\Payment\Helper\Payment $paymentHelper,
			\Magento\Quote\Api\CartRepositoryInterface $quoteRepository
	) {
		$this->_storeManager = $storeManager;
		$this->_dataHelper = $dataHelper;
		$this->_paymentHelper = $paymentHelper;
		$this->_quoteRepository = $quoteRepository;


		
		parent::__construct($context);
	}

	/**
	 * Redirect to checkout initial page (when payment cannot be done).
	 */
	protected function _redirectBack()
	{
		// clear all messages in session
		$this->messageManager->getMessages(true);

		$this->_dataHelper->log('Redirecting to cart page.');
		$this->_redirect('checkout/cart', array('_store' => $this->_storeManager->getStore()->getId()));
	}

	/**
	 * Redirect to error page (when technical error occured).
	 *
	 * @param \Magento\Sales\Model\Order $order
	 */
	protected function _redirectError($order)
	{
		// clear all messages in session
		$this->messageManager->getMessages(true);

		$this->_getCheckout()->setLastQuoteId($order->getQuoteId())
							->setLastOrderId($order->getId());

		$this->_dataHelper->log('Redirecting to failure page.');
		$this->_redirect('checkout/onepage/failure', array('_store' => $order->getStore()->getId()));
	}

	/**
	 * Redirect to result page (according to payment status).
	 *
	 * @param \Magento\Sales\Model\Order $order
	 * @param bool $success
	 * @param bool $checkUrlWarn
	 */
	protected function _redirectResponse($order, $success, $checkUrlWarn = false)
	{
		// clear all messages in session
		$this->messageManager->getMessages(true);

		$storeId = $order->getStore()->getId();
		if($this->_dataHelper->getCommonConfigData('ctx_mode', $storeId) == 'TEST') {
			// display going to production message
			$message = __('<p><u>GOING INTO PRODUCTION</u></p>You want to know how to put your shop into production mode, please go to this URL : ');
			$message .= '<a href="https://secure.payby.eu/html/faq/prod" target="_blank">https://secure.payby.eu/html/faq/prod</a>';
			$this->messageManager->addNotice($message);

			if($checkUrlWarn) {
				// order not validated by notification URL, in TEST mode, user is webmaster
				// so display a warning about notification URL not working

				if($this->_dataHelper->isMaintenanceMode()) {
					$message = __('The shop is in maintenance mode.The automatic notification cannot work.');
				} else {
					$message = __('The automatic validation hasn\'t worked. Have you correctly set up the notification URL in your Payby Back Office ?');
					$message .= '<br /><br />';
					$message .= __('For understanding the problem, please read the documentation of the module : <br />&nbsp;&nbsp;&nbsp;- Chapter &laquo;To read carefully before going further&raquo;<br />&nbsp;&nbsp;&nbsp;- Chapter &laquo;Notification URL settings&raquo;');
				}
				$this->messageManager->addError($message);
			}
		}

		if($success) {
			$this->_getCheckout()->setLastQuoteId($order->getQuoteId())
								->setLastSuccessQuoteId($order->getQuoteId())
								->setLastOrderId($order->getId())
								->setLastRealOrderId($order->getIncrementId())
								->setLastOrderStatus($order->getStatus());

			$this->_dataHelper->log('Redirecting to success page.');
			$this->_redirect('checkout/onepage/success', array('_store' => $storeId));
		} else {
			$this->_dataHelper->log('Unsetting order data in session.');
			$this->messageManager->addWarning(__('Checkout and order have been canceled.'));

			$this->_dataHelper->log("Restore cart for order #{$order->getId()} to allow re-order quicker.");
			$quote = $this->_quoteRepository->get($order->getQuoteId());
			if ($quote->getId()) {
				$quote->setIsActive(true)->setReservedOrderId(null);
				$this->_quoteRepository->save($quote);

				$this->_getCheckout()->replaceQuote($quote);
			}

			$this->_dataHelper->log('Redirecting to cart page.');
			$this->_redirect('checkout/cart', array('_store' => $storeId));
		}
	}

	/**
	 * Get checkout session namespace.
	 *
	 * @return \Magento\Checkout\Model\Session
	 */
	protected function _getCheckout()
	{
		return $this->_objectManager->get('Magento\Checkout\Model\Session');
	}
}