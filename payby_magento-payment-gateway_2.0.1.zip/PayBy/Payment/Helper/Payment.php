<?php

/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
 *
 * @category  payment
 * @package   payby  
 * @copyright PayBy.com
 * @version   2.0.0 
 */

namespace PayBy\Payment\Helper;

use PayBy\Payment\Model\Api\PaybyApi;

class Payment
{
	const IDENTIFIER = 'payby_identifier'; // key to save if payment is by identifier
	const CC_REGISTER = 'payby_cc_register'; // key to save if card data register is on
	const MULTI_OPTION = 'payby_multi_option'; // key to save choosen multi option
	const ONEY_OPTION = 'payby_oney_option'; // key to save choosen Oney option
	const RISK_CONTROL = 'payby_risk_control'; // key to save risk control results
	const RISK_ASSESSMENT = 'payby_risk_assessment'; // key to save risk assessment results
	const ALL_RESULTS = 'payby_all_results'; // key to save risk assessment results

	const ONECLICK_LOCATION_CART = 'CART';
	const ONECLICK_LOCATION_PRODUCT = 'PRODUCT';
	const ONECLICK_LOCATION_BOTH = 'BOTH';

	/**
	 * @var \Magento\Sales\Model\Order\Payment\Transaction\ManagerInterface
	 */
	protected $_transactionManager;

	/**
	 * @var \Magento\Sales\Api\TransactionRepositoryInterface
	 */
	protected $_transactionRepository;

	/**
	 * @var \Magento\Framework\ObjectManagerInterface
	 */
	protected $_objectManager;

	/**
	 * @var \Magento\Sales\Model\Order\Email\Sender\OrderSender
	 */
	protected $_orderSender;

	/**
	 * @var \PayBy\Payment\Helper\Data
	 */
	protected $_dataHelper;

	/**
	 * @param \Magento\Sales\Api\TransactionRepositoryInterface $transactionRepository
	 * @param \Magento\Sales\Model\Order\Payment\Transaction\ManagerInterface $transactionManager
	 * @param \Magento\Framework\ObjectManagerInterface $objectManager
	 * @param \Magento\Sales\Model\Order\Email\Sender\OrderSender $orderSender
	 * @param \PayBy\Payment\Helper\Data $dataHelper
	 */
	public function __construct(
		\Magento\Sales\Api\TransactionRepositoryInterface $transactionRepository,
		\Magento\Sales\Model\Order\Payment\Transaction\ManagerInterface $transactionManager,
		\Magento\Framework\ObjectManagerInterface $objectManager,
		\Magento\Sales\Model\Order\Email\Sender\OrderSender $orderSender,
		\PayBy\Payment\Helper\Data $dataHelper
	) {
		$this->_transactionRepository = $transactionRepository;
		$this->_transactionManager = $transactionManager;
		$this->_objectManager = $objectManager;
		$this->_orderSender = $orderSender;
		$this->_dataHelper = $dataHelper;
	}

	/**
	 *  Update order status and eventually create invoice.
	 *
	 *  @param \Magento\Sales\Model\Order $order
	 *  @param \PayBy\Payment\Model\Api\PaybyResponse $response
	 */
	public function registerOrder(\Magento\Sales\Model\Order $order, \PayBy\Payment\Model\Api\PaybyResponse $response)
	{
		$this->_dataHelper->log("Saving payment for order #{$order->getId()}.");

		// update authorized amount
		$order->getPayment()->setAmountAuthorized($order->getTotalDue());
		$order->getPayment()->setBaseAmountAuthorized($order->getBaseTotalDue());

		// retrieve new order state and status
		if ($response->isToValidatePayment()) {
			$newStatus = 'payby_to_validate';
			$newState = \Magento\Sales\Model\Order::STATE_PAYMENT_REVIEW;
		} elseif ($response->isPendingPayment()) {
			$newStatus = 'payment_review';
			$newState = \Magento\Sales\Model\Order::STATE_PAYMENT_REVIEW;
		} else {
			$newStatus = $this->_dataHelper->getCommonConfigData('registered_order_status', $order->getStore()->getId());

			$processingStatuses = $this->_objectManager->create('Magento\Sales\Model\Order\Config')->getStateStatuses(\Magento\Sales\Model\Order::STATE_PROCESSING, false);
			$newState = in_array($newStatus, $processingStatuses) ? \Magento\Sales\Model\Order::STATE_PROCESSING : \Magento\Sales\Model\Order::STATE_NEW;
		}

		if ($response->isSuspectedFraud()) {
			$newStatus = 'fraud';
			$newState = \Magento\Sales\Model\Order::STATE_PAYMENT_REVIEW;
		}

		$this->_dataHelper->log("Order #{$order->getId()}, new state : $newState, new status : $newStatus.");
		$order->setState($newState)
			->setStatus($newStatus)
			->addStatusHistoryComment('Call from PayBy API');

		// save platform responses
		$this->updatePaymentInfo($order, $response);

		// try to save Payby identifier if any
		//$this->saveIdentifier($order, $response);

		// try to create invoice
		$this->createInvoice($order);

		$this->_dataHelper->log("Saving confirmed order #{$order->getId()} and sending e-mail.");
		$order->save();

		if (!$order->getEmailSent()) {
			$this->_orderSender->send($order);
		}
	}

	public function updatePaymentInfo(\Magento\Sales\Model\Order $order, \PayBy\Payment\Model\Api\PaybyResponse $response)
	{
		$this->_dataHelper->log("updatePaymentInfo.");


		if ($acquireOrder = $response->get('acquireOrder')) {
			if (isset($acquireOrder['paymentInfo'])) {






				// set common payment information
				$order->getPayment()->setCcTransId($acquireOrder['orderNo'])
					->setCcType($acquireOrder['paymentInfo']['payChannel'])
					->setCcStatus($acquireOrder['status'])
					->setCcStatusDescription($acquireOrder['status'])
					->setAdditionalInformation(\PayBy\Payment\Helper\Payment::ALL_RESULTS, serialize($response->getAllResults()));

				if ($response->isCancelledPayment()) {
					// no more data to save
					return;
				}

				// save risk control result if any
				$riskControl = $response->getRiskControl();
				if (!empty($riskControl)) {
					$order->getPayment()->setAdditionalInformation(self::RISK_CONTROL, $riskControl);
				}

				// save risk assessment result if any
				$riskAssessment = $response->getRiskAssessment();
				if (!empty($riskAssessment)) {
					$order->getPayment()->setAdditionalInformation(self::RISK_ASSESSMENT, $riskAssessment);
				}

				// set is_fraud_detected flag
				$order->getPayment()->setIsFraudDetected($response->isSuspectedFraud());

				$currency = $acquireOrder['paymentInfo']['payeeFeeAmount']['currency']; //PaybyApi::findCurrencyByNumCode($response->get('currency'));





				$transactionId = $acquireOrder['orderNo'];

				$additionalInfo = array(
					'Transaction Type' => $acquireOrder['paymentInfo']['payChannel'],
					'Amount' => round($order->getTotalDue()),
					'Transaction ID' => $transactionId,
					'Transaction Status' => $acquireOrder['status'],
					'Payment Mean' => $acquireOrder['paymentInfo']['payChannel']
				);

				$transactionType = \Magento\Sales\Model\Order\Payment\Transaction::TYPE_CAPTURE;

				$this->addTransaction($order->getPayment(), $transactionType, $transactionId, $additionalInfo);


				// skip automatic transaction creation
				$order->getPayment()->setTransactionId(null)->setSkipTransactionCreation(true);
			}
		}
	}

	public function saveIdentifier(\Magento\Sales\Model\Order $order, \PayBy\Payment\Model\Api\PaybyResponse $response)
	{
		$this->_dataHelper->log("saveIdentifier.");
		if (!$order->getCustomerId()) {
			return;
		}

		if ($acquireOrder = $response->get('acquireOrder')) {
			if (isset($acquireOrder['paymentInfo']['payerMid'])) {
				$customer = $this->_objectManager->create('Magento\Customer\Model\Customer')->load($order->getCustomerId());

				$this->_dataHelper->log("Identifier for customer #{$customer->getId()} successfully created or updated on payment platform. Let's save it to customer entity.");

				$customer->setData('payby_identifier', $acquireOrder['paymentInfo']['payerMid']);
				$customer->save();

				$this->_dataHelper->log("Identifier for customer #{$customer->getId()} successfully saved to customer entity.");
			}
		}
	}

	public function createInvoice(\Magento\Sales\Model\Order $order)
	{
		// flag that is true if automatically create invoice
		$autoCapture = $this->_dataHelper->getCommonConfigData('capture_auto', $order->getStore()->getId());

		if (!$autoCapture || $order->getStatus() != 'processing' || !$order->canInvoice()) {
			// creating invoice not allowed
			return;
		}

		$this->_dataHelper->log("Creating invoice for order #{$order->getId()}.");

		// convert order to invoice
		$invoice = $order->prepareInvoice();
		$invoice->setRequestedCaptureCase(\Magento\Sales\Model\Order\Invoice::CAPTURE_OFFLINE);
		$invoice->setTransactionId($order->getPayment()->getLastTransId());
		$invoice->register()->save();
		$order->addRelatedObject($invoice);

		// add history entry
		$order->addStatusHistoryComment(__('Invoice %1 was created.', $invoice->getIncrementId()));
	}

	/**
	 * Cancel order.
	 *
	 * @param \Magento\Sales\Model\Order $order
	 * @param \PayBy\Payment\Model\Api\PaybyResponse $response
	 */
	public function cancelOrder(\Magento\Sales\Model\Order $order, \PayBy\Payment\Model\Api\PaybyResponse $response)
	{
		$this->_dataHelper->log("Canceling order #{$order->getId()}.");

		$order->registerCancellation($response->getMessage());

		// save platform responses
		$this->updatePaymentInfo($order, $response);

		$order->save();
	}

	/**
	 * Prepare transaction data and call \Magento\Sales\Model\Order\Payment::addTransaction.
	 *
	 * @param \Magento\Sales\Model\Order\Payment $payment
	 * @param string $type
	 * @param string $transactionId
	 * @param array $additionalInfo
	 * @param string $parentTransactionId
	 * @return null|\Magento\Sales\Model\Order\Payment\Transaction
	 */
	public function addTransaction($payment, $type, $transactionId, $additionalInfo)
	{
		$parentTxn = $this->_transactionRepository->getByTransactionId(
			$transactionId,
			$payment->getId(),
			$payment->getOrder()->getId()
		);

		if ($parentTxn && $parentTxn->getId()) {
			$payment->setTransactionId(
				$this->_transactionManager->generateTransactionId($payment, $type, $parentTxn)
			);
			$payment->setShouldCloseParentTransaction(true);
		} else {
			$payment->setTransactionId($transactionId);
		}
		$payment->setTransactionAdditionalInfo(\Magento\Sales\Model\Order\Payment\Transaction::RAW_DETAILS, $additionalInfo);

		if ($type == \Magento\Sales\Model\Order\Payment\Transaction::TYPE_AUTH) {
			$payment->setIsTransactionClosed(0);
		}

		$txnExists = $this->_transactionManager->isTransactionExists(
			$payment->getTransactionId(),
			$payment->getId(),
			$payment->getOrder()->getId()
		);

		$payment->setSkipTransactionCreation(false);
		$txn = $payment->addTransaction($type, null, true);

		$msg = $txnExists ? 'Transaction %1 was updated.' : 'Transaction %1 was created.';
		$payment->getOrder()->addStatusHistoryComment(__($msg, $payment->getTransactionId()));

		return $txn;
	}

	/**
	 * Convert Payby transaction status to magento transaction type.
	 *
	 * @param string $paybyType
	 * @return string
	 */
	public function convertTransactionType($paybyType)
	{
		$type = false;

		switch ($paybyType) {
			case 'UNDER_VERIFICATION':
			case 'INITIAL':
			case 'WAITING_AUTHORISATION_TO_VALIDATE':
			case 'WAITING_AUTHORISATION':
			case 'AUTHORISED_TO_VALIDATE':
			case 'AUTHORISED':
			case 'CAPTURE_FAILED':
				$type = \Magento\Sales\Model\Order\Payment\Transaction::TYPE_AUTH;
				break;

			case 'CAPTURED':
				$type = \Magento\Sales\Model\Order\Payment\Transaction::TYPE_CAPTURE;
				break;

			case 'REFUSED':
			case 'EXPIRED':
			case 'CANCELLED':
			case 'NOT_CREATED':
			case 'ABANDONED':
			default:
				$type = \Magento\Sales\Model\Order\Payment\Transaction::TYPE_VOID;
				break;
		}

		return $type;
	}
}
