<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
 *
 * @category  payment
 * @package   payby  
 * @copyright PayBy.com
 * @version   2.0.0 
 */
namespace PayBy\Payment\Block\Adminhtml\System\Config\Form\Field;

/**
 * Custom renderer for the Payby FacilyPay Oney shipping options field.
 */
class CustgroupOptions extends \PayBy\Payment\Block\Adminhtml\System\Config\Form\Field\FieldArray\ConfigFieldArray
{
	/**
	 * @var \Magento\Customer\Model\GroupFactory
	 */
	protected $_customerGroupFactory;

	/**
	 * @var bool
	 */
	protected $_static = true;

	/**
	 * @param \Magento\Backend\Block\Template\Context $context
	 * @param \Magento\Customer\Model\GroupFactory $customerGroupFactory
	 * @param array $data
	 */
	public function __construct(
			\Magento\Backend\Block\Template\Context $context,
			\Magento\Customer\Model\GroupFactory $customerGroupFactory,
			array $data = []
	) {
		$this->_customerGroupFactory = $customerGroupFactory;

		parent::__construct($context, $data);
	}

	/**
	 * Prepare to render.
	 *
	 * @return void
	 */
	public function _prepareToRender()
	{
		$this->addColumn('title', [
				'label' => __('Customer group'),
				'style' => 'width: 200px;',
				'renderer' => $this->_getLabelRenderer('_title')
		]);
		$this->addColumn('amount_min', [
				'label' => __('Minimum amount'),
				'style' => 'width: 160px;'
		]);
		$this->addColumn('amount_max', [
				'label' => __('Maximum amount'),
				'style' => 'width: 160px;'
		]);

		parent::_prepareToRender();
	}

	/**
	 * Obtain existing data from form element.
	 * Each row will be instance of \Magento\Framework\DataObject
	 *
	 * @return array
	 */
	public function getArrayRows()
	{
		/* var $groups Array[string][string] id => title */
		$groups = $this->_getAllCustomerGroups();

		$savedGroups = $this->getElement()->getValue();
		if(!is_array($savedGroups)) {
			$savedGroups = array();
		}

		if(count($savedGroups) > 0) {
			foreach ($savedGroups as $id => $savedGroup) {
				if(key_exists($savedGroup['code'], $groups)) {
					// refresh group title
					$savedGroups[$id]['title'] = $groups[$savedGroup['code']];
					if($savedGroup['code'] === 'all') {
						$savedGroups[$id]['all'] = true;
					}

					unset ($groups[$savedGroup['code']]);
				}
			}
		}

		// add not saved yet groups
		foreach ($groups as $code => $title) {
			$group = array(
					'code' => $code,
					'title' => $title,
					'amount_min' => '',
					'amount_max' => ''
			);

			if($code === 'all') {
				// add all groups entry
				$group['all'] = true;
				$savedGroups = array_merge(array(uniqid('_all_') => $group), $savedGroups);
			} else {
				$savedGroups[uniqid('_' . $code . '_')] = $group;
			}
		}

		$this->getElement()->setValue($savedGroups);
		return parent::getArrayRows();
	}

	private function _getAllCustomerGroups()
	{
		$options = array();
		$options['all'] = __('ALL GROUPS');

		$groups = $this->_customerGroupFactory->create()->getCollection();
		foreach ($groups as $group) {
			$options[$group->getCustomerGroupId()] = $group->getCustomerGroupCode();
		}

		return $options;
	}
}