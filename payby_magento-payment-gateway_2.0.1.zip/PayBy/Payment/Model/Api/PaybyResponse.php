<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
 *
 * @category  payment
 * @package   payby  
 * @copyright PayBy.com
 * @version   2.0.0 
 */
namespace PayBy\Payment\Model\Api;

if (! class_exists('PaybyResponse', false)) {

	/**
	 * Class representing the result of a transaction (sent by the IPN URL or by the client return).
	 */
	class PaybyResponse
	{
		const TYPE_RESULT = 'result';
		const TYPE_AUTH_RESULT = 'auth_result';
		const TYPE_WARRANTY_RESULT = 'warranty_result';
		const TYPE_RISK_CONTROL = 'risk_control';
		const TYPE_RISK_ASSESSMENT = 'risk_assessment';

		/**
		 * Raw response parameters array.
		 *
		 * @var array[string][string]
		 */
		private $rawResponse = array();

		/**
		 * Certificate used to check the signature.
		 *
		 * @see PaybyApi::sign
		 * @var string
		 */
		private $certificate;

		/**
		 * Value of vads_result.
		 *
		 * @var string
		 */
		private $result;

		/**
		 * Value of vads_extra_result.
		 *
		 * @var string
		 */
		private $extraResult;

		/**
		 * Value of vads_auth_result
		 *
		 * @var string
		 */
		private $authResult;

		/**
		 * Value of vads_warranty_result
		 *
		 * @var string
		 */
		private $warrantyResult;

		/**
		 * Transaction status (vads_trans_status)
		 *
		 * @var string
		 */
		private $transStatus;

		/**
		 * Constructor for PaybyResponse class.
		 * Prepare to analyse check URL or return URL call.
		 *
		 * @param array[string][string] $params
		 * @param string $ctx_mode
		 * @param string $key_test
		 * @param string $key_prod
		 * @param string $encoding
		 */
		public function __construct($params, $ctx_mode, $key_test, $key_prod)
		{
			$this->rawResponse = PaybyApi::uncharm($params);
			$this->certificate = $ctx_mode == 'PRODUCTION' ? $key_prod : $key_test;

			// payment results
			$this->result = self::findInArray('vads_result', $this->rawResponse, null);
			$this->extraResult = self::findInArray('vads_extra_result', $this->rawResponse, null);
			$this->authResult = self::findInArray('vads_auth_result', $this->rawResponse, null);
			$this->warrantyResult = self::findInArray('vads_warranty_result', $this->rawResponse, null);

			$this->transStatus = self::findInArray('vads_trans_status', $this->rawResponse, null);
		}

		/**
		 * Check response signature.
		 * @return bool
		 */
		public function isAuthentified()
		{
			return $this->getComputedSignature() == $this->getSignature();
		}

		/**
		 * Return the signature computed from the received parameters, for log/debug purposes.
		 * @param bool $hashed
		 * @return string
		 */
		public function getComputedSignature($hashed = true)
		{
			return PaybyApi::sign($this->rawResponse, $this->certificate, $hashed);
		}

		/**
		 * Check if the payment was successful (waiting confirmation or captured).
		 * @return bool
		 */
		public function isAcceptedPayment()
		{
			$confirmedStatuses = array('AUTHORISED', 'AUTHORISED_TO_VALIDATE', 'CAPTURED', 'CAPTURE_FAILED' /* capture will be redone */);
			return in_array($this->transStatus, $confirmedStatuses) || $this->isPendingPayment();
		}

		/**
		 * Check if the payment is waiting confirmation (successful but the amount has not been
		 * transfered and is not yet guaranteed).
		 * @return bool
		 */
		public function isPendingPayment()
		{
			$pendingStatuses = array('INITIAL', 'WAITING_AUTHORISATION', 'WAITING_AUTHORISATION_TO_VALIDATE', 'UNDER_VERIFICATION');
			return in_array($this->transStatus, $pendingStatuses);
		}

		/**
		 * Check if the payment process was interrupted by the client.
		 * @return bool
		 */
		public function isCancelledPayment()
		{
			$cancelledStatuses = array('NOT_CREATED', 'ABANDONED');
			return in_array($this->transStatus, $cancelledStatuses);
		}

		/**
		 * Check if the payment is to validate manually in the Payby Back Office.
		 * @return bool
		 */
		public function isToValidatePayment()
		{
			$toValidateStatuses = array('WAITING_AUTHORISATION_TO_VALIDATE', 'AUTHORISED_TO_VALIDATE');
			return in_array($this->transStatus, $toValidateStatuses);
		}

		/**
		 * Check if the payment is suspected to be fraudulent.
		 * @return bool
		 */
		public function isSuspectedFraud()
		{
			// at least one control failed ...
			$riskControl = $this->getRiskControl();
			if(in_array('WARNING', $riskControl) || in_array('ERROR', $riskControl)) {
				return true;
			}

			// or there was an alert from risk assessment module
			$riskAssessment = $this->getRiskAssessment();
			if(in_array('INFORM', $riskAssessment)) {
				return true;
			}

			return false;
		}

		/**
		 * Return the risk control result.
		 * @return array[string][string]
		 */
		public function getRiskControl()
		{
			$riskControl = $this->get('risk_control');
			if(!isset($riskControl) || !trim($riskControl)) {
				return array();
			}

			// get a URL-like string
			$riskControl = str_replace(';', '&', $riskControl);

			$result = array();
			parse_str($riskControl, $result);

			return $result;
		}

		/**
		 * Return the risk assessment result.
		 * @return array[string]
		 */
		public function getRiskAssessment()
		{
			$riskAssessment = $this->get('risk_assessment_result');
			if(!isset($riskAssessment) || !trim($riskAssessment)) {
				return array();
			}

			return explode(';', $riskAssessment);
		}

		/**
		 * Return the value of a response parameter.
		 * @param string $name
		 * @return string
		 */
		public function get($name)
		{
			// manage shortcut notations by adding 'vads_'
			$name = (substr($name, 0, 5) != 'vads_') ? 'vads_' . $name : $name;

			return @$this->rawResponse[$name];
		}

		/**
		 * Shortcut for getting ext_info_* fields.
		 * @param string $key
		 * @return string
		 */
		public function getExtInfo($key)
		{
			return $this->get("ext_info_$key");
		}

		/**
		 * Return the expected signature received from platform.
		 * @return string
		 */
		public function getSignature()
		{
			return @$this->rawResponse['signature'];
		}

		/**
		 * Return the paid amount converted from cents (or currency equivalent) to a decimal value.
		 * @return float
		 */
		public function getFloatAmount()
		{
			$currency = PaybyApi::findCurrencyByNumCode($this->get('currency'));
			return $currency->convertAmountToFloat($this->get('amount'));
		}

		/**
		 * Return the payment response result.
		 * @return string
		 */
		public function getResult()
		{
			return $this->result;
		}

		/**
		 * Return the payment response extra result.
		 * @return string
		 */
		public function getExtraResult()
		{
			return $this->extraResult;
		}

		/**
		 * Return the payment response authentication result.
		 * @return string
		 */
		public function getAuthResult()
		{
			return $this->authResult;
		}

		/**
		 * Return the payment response warranty result.
		 * @return string
		 */
		public function getWarrantyResult()
		{
			return $this->warrantyResult;
		}

		/**
		 * Return all the payment response results as array.
		 * @return string
		 */
		public function getAllResults()
		{
			return array(
					'result' => $this->result,
					'extraResult' => $this->extraResult,
					'auth_result' => $this->authResult,
					'warranty_result' => $this->warrantyResult
			);
		}

		/**
		 * Return the payment transaction status.
		 * @return string
		 */
		public function getTransStatus()
		{
			return $this->transStatus;
		}

		/**
		 * Return the payment response message translated to the payment langauge.
		 * @param $result_type string
		 * @return string
		 */
		public function getMessage($result_type = self::TYPE_RESULT)
		{
			$text = '';

			$msg = self::translate($this->get($result_type), $result_type, $this->get('language'));
			$text .= self::appendResultCode($msg, $this->get($result_type));

			if ($result_type === self::TYPE_RESULT && $this->get($result_type) === '30' /* form error */) {
				$msg = self::findInArray($this->extraResult, self::$FORM_ERRORS[$this->extraResult], 'OTHER');
				$text .= ' ' . self::appendResultCode($msg, $this->extraResult);
			}

			return $text;
		}

		/**
		 * Return a short description of the payment result, useful for logging.
		 * @return string
		 */
		public function getLogMessage()
		{
			$text = '';

			$msg = self::translate($this->result, self::TYPE_RESULT, 'en');
			$text .= self::appendResultCode($msg, $this->result);

			if ($this->result === '30' /* form error */) {
				$msg = self::findInArray($this->extraResult, self::$FORM_ERRORS[$this->extraResult], 'OTHER');
				$text .= ' ' . self::appendResultCode($msg, $this->extraResult);
			}

			$msg = self::translate($this->authResult, self::TYPE_AUTH_RESULT, 'en');
			$text .= ' ' . self::appendResultCode($msg, $this->authResult);

			$msg = self::translate($this->warrantyResult, self::TYPE_WARRANTY_RESULT, 'en');
			$text .= ' ' . self::appendResultCode($msg, $this->warrantyResult);

			return $text;
		}

		/**
		 * @deprecated Deprecated since version 1.2.1. Use <code>PaybyResponse::getLogMessage()</code>
		 * or <code>PaybyResponse::getMessage()</code> instead.
		 */
		public function getLogString()
		{
			return $this->getMessage();
		}

		/**
		 * Return a translated short description of the payment result for a specified language.
		 * @param string $result
		 * @param string $result_type
		 * @param string $lang
		 * @return string
		 */
		public static function translate($result, $result_type = self::TYPE_RESULT, $lang = 'en')
		{
			// if language is not supported, use the domain default language
			if(!key_exists($lang, self::$RESPONSE_TRANS)) {
				$lang = 'en';
			}

			if (!$result) {
				$result = 'empty';
			}

			$translations = self::$RESPONSE_TRANS[$lang];
			return self::findInArray($result, $translations[$result_type], $translations['unknown']);
		}

		/**
		 * @deprecated Deprecated since version 1.2.0. Use <code>PaybyResponse::getOutputForPlatform()</code> instead.
		 */
		public function getOutputForGateway($case = '', $extra_message = '', $original_encoding = 'UTF-8')
		{
			return $this->getOutputForPlatform($case, $extra_message, $original_encoding);
		}

		/**
		 * Return a formatted string to output as a response to the notification URL call.
		 *
		 * @param string $case shortcut code for current situations. Most useful : payment_ok, payment_ko, auth_fail
		 * @param string $extra_message some extra information to output to the payment platform
		 * @param string $original_encoding some extra information to output to the payment platform
		 * @return string
		 */
		public function getOutputForPlatform($case = '', $extra_message = '', $original_encoding = 'UTF-8')
		{
			// predefined response messages according to case
			$cases = array(
					'payment_ok' => array(true, 'Paiement valide traité'),
					'payment_ko' => array(true, 'Paiement invalide traité'),
					'payment_ok_already_done' => array(true, 'Paiement valide traité, déjà enregistré'),
					'payment_ko_already_done' => array(true, 'Paiement invalide traité, déjà enregistré'),
					'order_not_found' => array(false, 'Impossible de retrouver la commande'),
					'payment_ko_on_order_ok' => array(false, 'Code paiement invalide reçu pour une commande déjà validée'),
					'auth_fail' => array(false, 'Echec d\'authentification'),
					'ok' => array(true, ''),
					'ko' => array(false, '')
			);

			$success = key_exists($case, $cases) ? $cases[$case][0] : false;
			$message = key_exists($case, $cases) ? $cases[$case][1] : '';

			if (! empty($extra_message)) {
				$message .= ' ' . $extra_message;
			}
			$message = str_replace("\n", ' ', $message);

			// set original CMS encoding to convert if necessary response to send to platform
			$encoding = in_array(strtoupper($original_encoding), PaybyApi::$SUPPORTED_ENCODINGS) ? strtoupper($original_encoding) : 'UTF-8';
			if ($encoding !== 'UTF-8') {
				$message = iconv($encoding, 'UTF-8', $message);
			}

			$response = '';
			$response .= '<span style="display:none">';
			$response .= $success ? 'OK-' : 'KO-';
			$response .= $this->get('trans_id');
			$response .= "=$message\n";
			$response .= '</span>';
			return $response;
		}

		public static function appendResultCode($message, $result_code)
		{
			if ($result_code) {
				$message .= ' (' . $result_code . ')';
			}

			return $message . '.';
		}

		public static function findInArray($key, $array, $default)
		{
			if (is_array($array) && key_exists($key, $array)) {
				return $array[$key];
			}

			return $default;
		}

		/**
		 * Associative array containing human-readable translations of response codes.
		 *
		 * @var array
		 * @access private
		 */
		public static $RESPONSE_TRANS = array();

		public static $FORM_ERRORS = array();
	}
}