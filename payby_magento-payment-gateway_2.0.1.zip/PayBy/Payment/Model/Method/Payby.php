<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
 *
 * @category  payment
 * @package   payby  
 * @copyright PayBy.com
 * @version   2.0.0 
 */
namespace PayBy\Payment\Model\Method;

use PayBy\Payment\Model\Api\PaybyApi;

abstract class Payby extends \Magento\Payment\Model\Method\AbstractMethod
{
	protected $_infoBlockType = 'PayBy\Payment\Block\Payment\Info';

	protected $_isplatform = true;
	protected $_canAuthorize = true;
	protected $_canCapture = true;
	protected $_canCapturePartial = true;
// 	protected $_canRefund = true;
// 	protected $_canRefundInvoicePartial = true;
	protected $_canVoid = true;
	protected $_canUseForMultishipping = false;
// 	protected $_canUseInternal = true;
	protected $_canUseCheckout = true;
	protected $_isInitializeNeeded = true;
	protected $_canSaveCc = false;
// 	protected $_canReviewPayment = true;

	/**
	 * @var \Magento\Framework\ObjectManagerInterface
	 */
	protected $_objectManager;

	/**
	 * @var \Magento\Framework\Locale\ResolverInterface
	 */
	protected $_localeResolver;

	/**
	 * @var \Magento\Framework\UrlInterface
	 */
	protected $_urlBuilder;

	/**
	 * @var \PayBy\Payment\Model\Api\PaybyRequest
	 */
	protected $_paybyRequest;

	/**
	 * @var \PayBy\Payment\Helper\Data
	 */
	protected $_dataHelper;

	/**
	 * @var \PayBy\Payment\Helper\Payment
	 */
	protected $_paymentHelper;

	/**
	 * @var \PayBy\Payment\Helper\Checkout
	 */
	protected $_checkoutHelper;

	/**
	 * @param \Magento\Framework\Model\Context $context
	 * @param \Magento\Framework\Registry $registry
	 * @param \Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory
	 * @param \Magento\Framework\Api\AttributeValueFactory $customAttributeFactory
	 * @param \Magento\Payment\Helper\Data $paymentData
	 * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
	 * @param \Magento\Payment\Model\Method\Logger $logger
	 * @param \Magento\Framework\ObjectManagerInterface $objectManager
	 * @param \Magento\Framework\Locale\ResolverInterface $localeResolver
	 * @param \Magento\Framework\UrlInterface $urlBuilder
	 * @param \PayBy\Payment\Model\Api\PaybyRequest $paybyRequest
	 * @param \PayBy\Payment\Helper\Data $dataHelper
	 * @param \PayBy\Payment\Helper\Payment $paymentHelper
	 * @param \PayBy\Payment\Helper\Checkout $checkoutHelper
	 * @param \Magento\Framework\Model\ResourceModel\AbstractResource $resource
	 * @param \Magento\Framework\Data\Collection\AbstractDb $resourceCollection
	 * @param array $data
	 */
	public function __construct(
			\Magento\Framework\Model\Context $context,
			\Magento\Framework\Registry $registry,
			\Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory,
			\Magento\Framework\Api\AttributeValueFactory $customAttributeFactory,
			\Magento\Payment\Helper\Data $paymentData,
			\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
			\Magento\Payment\Model\Method\Logger $logger,
			\Magento\Framework\ObjectManagerInterface $objectManager,
			\Magento\Framework\Locale\ResolverInterface $localeResolver,
			\Magento\Framework\UrlInterface $urlBuilder,
			\PayBy\Payment\Model\Api\PaybyRequestFactory $paybyRequestFactory,
			\PayBy\Payment\Helper\Data $dataHelper,
			\PayBy\Payment\Helper\Payment $paymentHelper,
			\PayBy\Payment\Helper\Checkout $checkoutHelper,
			\Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
			\Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
			array $data = []
	) {

		$this->_objectManager = $objectManager;
		$this->_localeResolver = $localeResolver;
		$this->_urlBuilder = $urlBuilder;
		$this->_paybyRequest = $paybyRequestFactory->create();
		$this->_dataHelper = $dataHelper;
		$this->_paymentHelper = $paymentHelper;
		$this->_checkoutHelper = $checkoutHelper;

		parent::__construct(
				$context,
				$registry,
				$extensionFactory,
				$customAttributeFactory,
				$paymentData,
				$scopeConfig,
				$logger,
				$resource,
				$resourceCollection,
				$data
		);
	}
 

	abstract protected function _setExtraFields($order);


	/**
	 * Retrieve information from payment configuration.
	 *
	 * @param string $field
	 * @param int|string|null|\Magento\Store\Model\Store $storeId
	 * @return mixed
	 */
	public function getConfigData($field, $storeId = null) {
		if (is_null($storeId) && !$this->getStore()) {
			$storeId = $this->_dataHelper->getCheckoutStoreId();
		}

		return parent::getConfigData($field, $storeId);
	}

	/**
	 * Return the payment platform URL.
	 *
	 * @return string
	 */
	public function getPlatformUrl() {
		return $this->_dataHelper->getCommonConfigData('platform_url');
	}

	/**
	 * Return true if redirection will be done in silent mode.
	 *
	 * @return bool
	 */
	public function isSilentMode() {
		return false;
	}

	/**
	 * Reset data of info model instance.
	 *
	 * @return $this
	 */
	public function resetData()
	{
		$info = $this->getInfoInstance();

		$info->unsAdditionalInformation()
				->setAdditionalData(null)
				->setCcType(null)
				->setCcLast4(null)
				->setCcNumber(null)
				->setCcCid(null)
				->setCcExpMonth(null)
				->setCcExpYear(null);

		return $this;
	}


	/**
	 * Method that will be executed instead of authorize or capture if flag isInitializeNeeded set to true.
	 *
	 * @param string $paymentAction
	 * @param object $stateObject
	 *
	 * @return $this
	 */
	public function initialize($paymentAction, $stateObject) {
		$this->_dataHelper->log("Initialize payment called with action $paymentAction.");

		if($paymentAction !== \Magento\Payment\Model\Method\AbstractMethod::ACTION_AUTHORIZE) {
			return;
		}

		// avoid sending order by e-mail before redirection
		$order = $this->getInfoInstance()->getOrder();
		$order->setCanSendNewEmailFlag(false);

		$stateObject->setState(\Magento\Sales\Model\Order::STATE_PENDING_PAYMENT);
		$stateObject->setStatus('pending_payment');
		$stateObject->setIsNotified(false);

		return $this;
	}

	/**
	 * Check method for processing with base currency.
	 *
	 * @param string $currencyCode
	 * @return bool
	 */
	public function canUseForCurrency($currencyCode) {
		// Check currency support
		if($currencyCode=='AED'){
			return true;
		}else{
			$this->_dataHelper->log("Could not find currency numeric code for currency : $currencyCode.");
			return false;
		}
	}

	/**
	 * Return true if the method can be used at this time.
	 *
	 * @param \Magento\Quote\Api\Data\CartInterface|null $quote
	 * @return bool
	 */
	public function isAvailable(\Magento\Quote\Api\Data\CartInterface $quote=null) {
		if(! parent::isAvailable($quote)) {
			return false;
		}

		$amount = $quote ? $quote->getBaseGrandTotal() : null;
		if(!$amount) {
			return true;
		}

		$configOptions = unserialize($this->getConfigData('custgroup_amount_restrictions'));
		if(!is_array($configOptions) || count($configOptions) <= 0) {
			return true;
		}

		$group = $quote && $quote->getCustomer() ? $quote->getCustomer()->getGroupId() : null;

		$allMinAmount = null;
		$allMaxAmount = null;
		$minAmount = null;
		$maxAmount = null;
		foreach ($configOptions as $key => $value) {
			if(empty($value)) {
				continue;
			}

			if($value['code'] === 'all') {
				$allMinAmount = $value['amount_min'];
				$allMaxAmount = $value['amount_max'];
			} elseif ($value['code'] === $group) {
				$minAmount = $value['amount_min'];
				$maxAmount = $value['amount_max'];
			}
		}

		if(!$minAmount) {
			$minAmount = $allMinAmount;
		}
		if(!$maxAmount) {
			$maxAmount = $allMaxAmount;
		}

		if(($minAmount && ($amount < $minAmount))
				|| ($maxAmount && ($amount > $maxAmount))) {
			// module will not be available
			return false;
		}

		return true;
	}
}