<?php

namespace PayBy\Payment\Model;

class PayBy
{
    /**
     * @var string The PayBy app ID to be used for users/coupons/balances/...
     */
    public static $partnerId = null;
    /**
     * @var string The base URL for the PayBy API.
     */
    public static $apiBase = 'https://uat.test2pay.com/sgs/api';
    /**
     * @var string|null The version of the PayBy API to use for requests.
     */
    public static $apiVersion = null;
    /**
     * @var boolean Defaults to true.
     */
    public static $verifySslCerts = true;

    const VERSION = '0.0.9';

    /**
     * @var string The public key to be used for signing requests.
     */
    public static $publicKey;

    /**
     * @var string The PEM formatted private key to be used for signing requests.
     */
    public static $privateKey;

    /**
     * @var string The CA certificate path.
     */
    public static $caBundle;



    
    private $_dataHelper;
    public function __construct(
        \PayBy\Payment\Helper\Data $dataHelper
    ) {
        $this->_dataHelper = $dataHelper; 
    }
    /**
     * @return string The app ID used for requests.
     */
    public static function getPartnerId()
    {
        return self::$partnerId;
    }
    public static function getApiBase()
    {

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $storeManager = $objectManager->get('Magento\Store\Model\StoreManagerInterface'); 
        $storeId = $storeManager->getStore()->getStoreId(); 

        $_dataHelper = $objectManager->get('PayBy\Payment\Helper\Data'); 

        $ctx_mode = $_dataHelper->getCommonConfigData('ctx_mode', $storeId);
        if ($ctx_mode == 'TEST') {
            return self::$apiBase = 'https://uat.test2pay.com/sgs/api';

        }else{
            return self::$apiBase = 'https://api.payby.com/sgs/api';
        }

 
    }


    /**
     * Sets the app ID to be used for requests.
     *
     * @param string $partnerId
     */
    public static function setPartnerId($partnerId)
    {
        self::$partnerId = $partnerId;
    }

    /**
     * @return string The API version used for requests. null if we're using the
     *    latest version.
     */
    public static function getApiVersion()
    {
        return self::$apiVersion;
    }

    /**
     * @param string $apiVersion The API version to use for requests.
     */
    public static function setApiVersion($apiVersion)
    {
        self::$apiVersion = $apiVersion;
    }

    /**
     * @return boolean
     */
    public static function getVerifySslCerts()
    {
        return self::$verifySslCerts;
    }

    /**
     * @param boolean $verify
     */
    public static function setVerifySslCerts($verify)
    {
        self::$verifySslCerts = $verify;
    }

    /**
     * @return string
     */
    public static function getPublicKey()
    {
        return self::$PublicKey;
    }

    /**
     * @param string $path
     */
    public static function setPublicKey($path)
    {
        self::$publicKey = $path;
    }


    /**
     * @return string
     */
    public static function getPrivateKey()
    {
        return self::$privateKey;
    }

    /**
     * @param string $key
     */
    public static function setPrivateKey($key)
    {
        self::$privateKey = $key;
    }
}
