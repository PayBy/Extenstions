<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
  
 * @category  payment
 * @package   payby

 * @copyright  2020
 * @license      Commercial License 
 * @version   2.0.0 
 */
namespace PayBy\Payment\Model\System\Config\Source;

class ValidationMode extends \Magento\Framework\DataObject implements \Magento\Framework\Option\ArrayInterface
{
	public function toOptionArray()
	{
		$options = [
				['value' => '', 'label' => __('Back Office configuration')],
				['value' => '0', 'label' => __('Automatic')],
				['value' => '1', 'label' => __('Manual')]
		];

		if(stripos($this->getPath(), '/payby_general/') === false) {
			array_unshift($options, ['value' => '-1', 'label' => __('Payby general configuration')]);
		}

		return $options;
	}
}