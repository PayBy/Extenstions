<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
  
 * @category  payment
 * @package   payby

 * @copyright  2020
 * @license      Commercial License 
 * @version   2.0.0 
 */
namespace PayBy\Payment\Model\System\Config\Backend;

class Logo extends \Magento\Config\Model\Config\Backend\Image
{
	public function beforeSave()
	{
		$value = $this->getValue();
		$value['value'] = $value['name'];
		$this->setValue($value);

		parent::beforeSave();

		// recover the last saved value
		if(!$this->getValue() && empty($value['delete'])) {
			$this->setValue($this->getOldValue());
		}

		return $this;
	}
}