<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
  
 * @category  payment
 * @package   payby

 * @copyright  2020
 * @license      Commercial License 
 * @version   2.0.0 
 */
namespace PayBy\Payment\Model\System\Config\Backend;

class AvailableLanguages extends \Magento\Framework\App\Config\Value
{
	public function save()
	{
		$value = $this->getValue();

		if(in_array('', $value)) {
			$this->setValue(array());
		}

		return parent::save();
	}
}