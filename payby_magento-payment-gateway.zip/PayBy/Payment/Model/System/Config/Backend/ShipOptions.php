<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
  
 * @category  payment
 * @package   payby

 * @copyright  2020
 * @license      Commercial License 
 * @version   2.0.0 
 */
namespace PayBy\Payment\Model\System\Config\Backend;

class ShipOptions extends \PayBy\Payment\Model\System\Config\Backend\Serialized\ArraySerialized\ConfigArraySerialized
{
	public function beforeSave()
	{
		$data = $this->getGroups('payby'); // get data of general config group
		$oneyContract = isset($data['fields']['oney_contract']['value']) && $data['fields']['oney_contract']['value'];

		if($oneyContract) {
			$deliveryCompanyRegex = "#^[A-Z0-9ÁÀÂÄÉÈÊËÍÌÎÏÓÒÔÖÚÙÛÜÇ /'-]{1,127}$#ui";

			$values = $this->getValue();

			if(!is_array($values) || empty($values)) {
				$this->setValue(array());
			} else {
				$i = 0;
				foreach ($values as $key => $value) {
					$i++;

					if(empty($value)) {
						continue;
					}

					if(empty($value['oney_label']) || !preg_match($deliveryCompanyRegex, $value['oney_label'])) {
						$this->_throwException('FacilyPay Oney label', $i);
					}
				}
			}
		} else {
			$this->setValue(array());
		}

		return parent::beforeSave();
	}
}