<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
  
 * @category  payment
 * @package   payby

 * @copyright  2020
 * @license      Commercial License 
 * @version   2.0.0 
 */
namespace PayBy\Payment\Model\System\Config\Backend;

class NotifyUrl extends \Magento\Framework\App\Config\Value
{
	/**
	 * @var \Magento\Store\Model\StoreManagerInterface
	 */
	protected $_storeManager;

	/**
	 * @var \Magento\Framework\UrlInterface
	 */
	protected $_url;

	/**
	 * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $config
     * @param \Magento\Framework\App\Cache\TypeListInterface $cacheTypeList
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
	 * @param \Magento\Framework\UrlInterface $url
     * @param \Magento\Framework\Model\ResourceModel\AbstractResource|null $resource
     * @param \Magento\Framework\Data\Collection\AbstractDb|null $resourceCollection
     * @param array $data
	 */
	public function __construct(
			\Magento\Framework\Model\Context $context,
			\Magento\Framework\Registry $registry,
			\Magento\Framework\App\Config\ScopeConfigInterface $config,
			\Magento\Framework\App\Cache\TypeListInterface $cacheTypeList,
			\Magento\Store\Model\StoreManagerInterface $storeManager,
			\Magento\Framework\UrlInterface $url,
			\Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
			\Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
			array $data = []
	) {
		$this->_storeManager = $storeManager;
		$this->_url = $url;

		parent::__construct($context, $registry, $config, $cacheTypeList, $resource, $resourceCollection, $data);
	}

	/**
	 * Processing object after load data
	 *
	 * @return Mage_Core_Model_Abstract
	 */
	protected function _afterLoad()
	{
		$store = $this->_storeManager->getDefaultStoreView();

		if (!$store) { // if no default store, retrieve any other
			foreach ($this->_storeManager->getStores() as $aStore) {
				$store = $aStore;
				break;
			}
		}

		$params = [
				'_secure' => $store->isCurrentlySecure(),
				'_nosid' => true
		];

		$notifyUrl = $this->_url->setScope($store->getId())->getUrl($this->getValue(), $params);
		$this->setValue($notifyUrl);

		return parent::_afterLoad();
	}
}