<?php

namespace PayBy\Payment\Model\Error;
class Authentication extends Base
{
}
