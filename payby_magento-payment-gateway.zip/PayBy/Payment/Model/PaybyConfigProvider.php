<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
 *
 * @category  payment
 * @package   payby  
 * @copyright PayBy.com
 * @version   2.0.0 
 */
namespace PayBy\Payment\Model;

class PaybyConfigProvider implements \Magento\Checkout\Model\ConfigProviderInterface
{
	/**
	 * @var \Magento\Store\Model\StoreManagerInterface
	 */
	protected $_storeManager;

	/**
	 * @var \Magento\Framework\View\Asset\Repository
	 */
	protected $_assetRepo;

	/**
	 * @var Magento\Framework\App\RequestInterface
	 */
	protected $_request;

	/**
	 * @var \Magento\Framework\UrlInterface
	 */
	protected $_urlBuilder;

	/**
	 * @var \Psr\Log\LoggerInterface
	 */
	protected $_logger;

	/**
	 * @var \PayBy\Payment\Helper\Data
	 */
	protected $_dataHelper;

	/**
	 * @var \PayBy\Payment\Model\Method\Payby
	 */
	protected $_method;

	/**
	 * @param \Magento\Store\Model\StoreManagerInterface $storeManager
	 * @param \Magento\Framework\View\Asset\Repository $assetRepo
	 * @param \Magento\Framework\App\RequestInterface $request
	 * @param \Magento\Framework\UrlInterface $urlBuilder
	 * @param \Psr\Log\LoggerInterface $logger
	 * @param \Magento\Payment\Helper\Data $paymentHelper
	 * @param \PayBy\Payment\Helper\Data $dataHelper
	 * @param string $methodCode
	 */
	public function __construct(
			\Magento\Store\Model\StoreManagerInterface $storeManager,
			\Magento\Framework\View\Asset\Repository $assetRepo,
			\Magento\Framework\App\RequestInterface $request,
			\Magento\Framework\UrlInterface $urlBuilder,
			\Psr\Log\LoggerInterface $logger,
			\Magento\Payment\Helper\Data $paymentHelper,
			\PayBy\Payment\Helper\Data $dataHelper,
			$methodCode
	) {
		$this->_storeManager = $storeManager;
		$this->_assetRepo = $assetRepo;
		$this->_request = $request;
		$this->_urlBuilder = $urlBuilder;
		$this->_logger = $logger;
		$this->_method = $paymentHelper->getMethodInstance($methodCode);
		$this->_dataHelper = $dataHelper;

		$this->_method->setStore($this->_storeManager->getStore()->getId());
	}

	/**
	 * {@inheritdoc}
	 */
	public function getConfig()
	{
		return [
				'payment' => [
						$this->_method->getCode() => [
								'checkoutRedirectUrl' => $this->getCheckoutRedirectUrl(),
								'moduleLogoUrl' => $this->getModuleLogoUrl()
						]
				]
		];
	}

	protected function getModuleLogoUrl()
	{
		$fileName = $this->_method->getConfigData('module_logo');
		if ($this->_dataHelper->isUploadFileImageExists($fileName)) {
			return $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA) . 'payby/images/' . $fileName;
		} else {
			return $this->getViewFileUrl('PayBy_Payment::images/' . $fileName);
		}
	}

	/**
	 * Retrieve url of a view file
	 *
	 * @param string $fileId
	 * @param array $params
	 * @return string[]
	 */
	protected function getViewFileUrl($fileId, array $params = [])
	{
		try {
			$params = array_merge(['_secure' => $this->_request->isSecure()], $params);
			return $this->_assetRepo->getUrlWithParams($fileId, $params);
		} catch (LocalizedException $e) {
			$this->_logger->critical($e);
			return $this->_urlBuilder->getUrl('', ['_direct' => 'core/index/notFound']);
		}
	}

	/**
	 * Checkout redirect URL getter
	 *
	 * @return string
	 */
	public function getCheckoutRedirectUrl()
	{
		return $this->_urlBuilder->getUrl('payby/payment/redirect', array('_secure' => true));
	}
}