/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
  
 * @category  payment
 * @package   payby

 * @copyright  2020
 * @license      Commercial License 
 * @version   2.0.0 
 */

/*browser:true*/
/*global define*/
define(
	[
		'jquery',
		'Magento_Checkout/js/view/payment/default'
	],
	function ($, Component) {
		'use strict';

		return Component.extend({
			defaults: {
				redirectAfterPlaceOrder: false
			},

			getModuleLogoUrl: function () {
				return window.checkoutConfig.payment[this.item.method].moduleLogoUrl;
			},

			/**
			 * After place order callback
			 */
			afterPlaceOrder: function () {
				// order placed with payment_pending status, redirect to platform 
				$.mage.redirect(window.checkoutConfig.payment[this.item.method].checkoutRedirectUrl);
			}
		});
	}
);