<?php

/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
  
 * @category  payment
 * @package   payby

 * @copyright  2020
 * @license      Commercial License 
 * @version   2.0.0 
 */

namespace PayBy\Payment\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use Magento\Sales\Model\Order;
use Magento\Framework\Message\ManagerInterface;
use Magento\Framework\Exception\LocalizedException;

class SalesOrderCreditmemoSaveAfter implements ObserverInterface
{
    private $messageManager;
    private $_dataHelper;
    public function __construct(
        ManagerInterface $messageManager,
        \PayBy\Payment\Helper\Data $dataHelper
    ) {
        $this->messageManager = $messageManager;
        $this->_dataHelper = $dataHelper;
    }


    public function convertToBaseCurrency($amount = 0, $store = null, $currency = null)
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $priceCurrencyObject = $objectManager->get('Magento\Framework\Pricing\PriceCurrencyInterface');
        //instance of PriceCurrencyInterface
        $storeManager = $objectManager->get('Magento\Store\Model\StoreManagerInterface');
        //instance of StoreManagerInterface
        if ($store == null) {
            $store = $storeManager->getStore()->getStoreId();
            //get current store id if store id not get passed
        }
        $rate = $priceCurrencyObject->convert($amount, $store, $currency);
        //it return price according to current store from base currency



        return array('value_for_aed' => $rate, 'store' => $store);
    }

    /**
     *
     * @param Observer $observer
     * @return void
     */
    public function execute(Observer $observer)
    {
        $this->_dataHelper->log("Order refund observer start.");
        /** @var \Magento\Sales\Model\Order\Creditmemo $creditmemo */
        $creditmemo = $observer->getEvent()->getCreditmemo();

        /** @var \Magento\Sales\Model\Order $order */
        $order = $creditmemo->getOrder();



        if ($this->_dataHelper->isPaidUsingPayby($order)) {
            $this->_dataHelper->log("Payby order refund observer start.");

            $order->addStatusHistoryComment(__('Order refund sent to Payby platform.'), false)
                ->setIsCustomerNotified(false)
                ->save();





            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $storeManager = $objectManager->get('Magento\Store\Model\StoreManagerInterface');
            $storeId = $storeManager->getStore()->getStoreId();

            $partner_id = $this->_dataHelper->getCommonConfigData('partner_id', $storeId);
            $ctx_mode = $this->_dataHelper->getCommonConfigData('ctx_mode', $storeId);
            if ($ctx_mode == 'TEST') {
                \PayBy\Payment\Model\PayBy::$caBundle = __DIR__ . '/../../cert/cacert.pem';
                //$key__sign=__DIR__ . '/../../cert/PayBy_key_private-sign.pem';
                //$key_prod_verify=__DIR__ . '/../../cert/PayBy_key_public_key-verify.pem';
                $key_test_sign = ($this->_dataHelper->getCommonConfigData('key_test_sign', $storeId));
                $key_test_verify = ($this->_dataHelper->getCommonConfigData('key_test_verify', $storeId));
                \PayBy\Payment\Model\PayBy::setPrivateKey($key_test_sign);
                \PayBy\Payment\Model\PayBy::setPublicKey($key_test_verify);
            } else {
                \PayBy\Payment\Model\PayBy::$caBundle = __DIR__ . '/../../cert/cacert.pem';
                $key_prod_sign = ($this->_dataHelper->getCommonConfigData('key_prod_sign', $storeId));
                $key_prod_verify = ($this->_dataHelper->getCommonConfigData('key_prod_verify', $storeId));
                \PayBy\Payment\Model\PayBy::setPrivateKey($key_prod_sign);
                \PayBy\Payment\Model\PayBy::setPublicKey($key_prod_verify);
            }
            \PayBy\Payment\Model\PayBy::setPartnerId($partner_id);




            try {

                $merchantOrderNo = $order->getIncrementId();
                $merchantCreditmemoNo = $creditmemo->getIncrementId();
                $requestTime = time();
                $currency = $order->getOrderCurrencyCode();
                $amount = sprintf('%.2f', $creditmemo->getGrandTotal());
                if ($order->getOrderCurrencyCode() == 'AED') {
    
                    $aed_amount = $amount;
                } else {
                    $amount_converted = ($this->convertToBaseCurrency($amount, null, 'AED'));
                    $aed_amount = $amount_converted['value_for_aed'];
                } 
                $requestData = [
                    'refundMerchantOrderNo' => $merchantCreditmemoNo,
                    'originMerchantOrderNo' => $merchantOrderNo,
                    "amount" => [
                        "currency" => "AED",
                        "amount" => $aed_amount
                    ],
                    "operatorName" => "magento",
                    "reason" => "refund"
    
    
    
                ];
                $this->_dataHelper->log('refund requestData:' . json_encode($requestData));
                // bizContent
                $or = \PayBy\Payment\Model\Api\Refund::placeOrder($requestData);
                if (isset($or->head->code)) {
                    $this->_dataHelper->log('refund resultData:' .json_encode($or));
                    $code = ($or->head->code);
                    if ($code != 0) {

                        $this->messageManager->addErrorMessage('Order refund API error:' . $or->head->msg);
                        throw new LocalizedException(
                            __('Order refund API error:' . $or->head->msg)
                        ); 

                    }
                }
            } catch (\PayBy\Payment\Model\Error\Base $e) {
                // 捕获报错信息
                $this->messageManager->addErrorMessage($e->getMessage());
                throw new LocalizedException(
                    __('Error API: %1', $e->getMessage())
                );
            }
        }
    }
}
