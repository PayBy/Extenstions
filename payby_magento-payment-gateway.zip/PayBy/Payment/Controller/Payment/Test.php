<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
 *
 * @category  payment
 * @package   payby  
 * @copyright PayBy.com
 * @version   2.0.0 
 */
namespace PayBy\Payment\Controller\Payment;




if (!function_exists('curl_init')) {
    throw new Exception('PayBy needs the CURL PHP extension.');
}
if (!function_exists('json_decode')) {
    throw new Exception('PayBy needs the JSON PHP extension.');
}
if (!function_exists('mb_detect_encoding')) {
    throw new Exception('PayBy needs the Multibyte String PHP extension.');
}
/*
// PayBy
require(dirname(__FILE__) . '/../../Model/PayBy.php');

// Utilities
require(dirname(__FILE__) . '/../../Model/Util/Util.php');
require(dirname(__FILE__) . '/../../Model/Util/Set.php');

// Errors
require(dirname(__FILE__) . '/../../Model/Error/Base.php');
require(dirname(__FILE__) . '/../../Model/Error/Api.php');
require(dirname(__FILE__) . '/../../Model/Error/ApiConnection.php');
require(dirname(__FILE__) . '/../../Model/Error/Authentication.php');
require(dirname(__FILE__) . '/../../Model/Error/InvalidRequest.php');

require(dirname(__FILE__) . '/../../Model/PayByObject.php');

// Api Base
require(dirname(__FILE__) . '/../../Model/Api/ApiRequestor.php');
require(dirname(__FILE__) . '/../../Model/Api/ApiResource.php');

// PayBy API Resources
require(dirname(__FILE__) . '/../../Model/Api/Order.php');

*/


class Test extends \PayBy\Payment\Controller\Payment
{
    /**
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry;
    protected $_priceHelper;

    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $_resultPageFactory;

    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \PayBy\Payment\Helper\Data $dataHelper
     * @param \PayBy\Payment\Helper\Payment $paymentHelper
     * @param \Magento\Quote\Api\CartRepositoryInterface $quoteRepository
     * @param \Magento\Framework\Registry $coreRegistry
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     */
    public function __construct(
            \Magento\Framework\App\Action\Context $context,
            \Magento\Store\Model\StoreManagerInterface $storeManager,
            \PayBy\Payment\Helper\Data $dataHelper,
            \PayBy\Payment\Helper\Payment $paymentHelper,
            \Magento\Quote\Api\CartRepositoryInterface $quoteRepository,
            \Magento\Framework\Registry $coreRegistry,
            \Magento\Framework\Pricing\Helper\Data $priceHelper,
            \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {
        $this->_coreRegistry = $coreRegistry;
        $this->_resultPageFactory = $resultPageFactory;
        $this->_priceHelper = $priceHelper;

        parent::__construct($context, $storeManager, $dataHelper, $paymentHelper, $quoteRepository);
    } 
    public function convertToBaseCurrency($amount = 0, $store = null, $currency = null)
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $priceCurrencyObject = $objectManager->get('Magento\Framework\Pricing\PriceCurrencyInterface'); 
        //instance of PriceCurrencyInterface
        $storeManager = $objectManager->get('Magento\Store\Model\StoreManagerInterface'); 
        //instance of StoreManagerInterface
        if ($store == null) {
            $store = $storeManager->getStore()->getStoreId(); 
            //get current store id if store id not get passed
        }
        $rate = $priceCurrencyObject->convert($amount, $store, $currency); 
        //it return price according to current store from base currency
        
      

        $formattedCurrencyValue = $this->_priceHelper->currencyByStore($amount,  $store, $format = false, $includeContainer = false);
        return array('value_for_aed'=>$rate,'value'=>$formattedCurrencyValue,'store'=>$store);


 
    
    }
    public function execute()
    { 
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $storeManager = $objectManager->get('Magento\Store\Model\StoreManagerInterface'); 
        $storeId = $storeManager->getStore()->getStoreId(); 

		$partner_id=$this->_dataHelper->getCommonConfigData('partner_id', $storeId);
        $ctx_mode=$this->_dataHelper->getCommonConfigData('ctx_mode', $storeId);
        if($ctx_mode=='TEST'){
            \PayBy\Payment\Model\PayBy::$caBundle=__DIR__ . '/../../cert/cacert.pem';
            //$key__sign=__DIR__ . '/../../cert/PayBy_key_private-sign.pem';
            //$key_prod_verify=__DIR__ . '/../../cert/PayBy_key_public_key-verify.pem';
            $key_test_sign=($this->_dataHelper->getCommonConfigData('key_test_sign', $storeId));
            $key_test_verify=($this->_dataHelper->getCommonConfigData('key_test_verify', $storeId));
            \PayBy\Payment\Model\PayBy::setPrivateKey($key_test_sign);
            \PayBy\Payment\Model\PayBy::setPublicKey($key_test_verify);

        }else{
            \PayBy\Payment\Model\PayBy::$caBundle=__DIR__ . '/../../cert/cacert.pem';
            $key_prod_sign=($this->_dataHelper->getCommonConfigData('key_prod_sign', $storeId));
            $key_prod_verify=($this->_dataHelper->getCommonConfigData('key_prod_verify', $storeId));
            \PayBy\Payment\Model\PayBy::setPrivateKey($key_prod_sign);
            \PayBy\Payment\Model\PayBy::setPublicKey($key_prod_verify);

        }
        \PayBy\Payment\Model\PayBy::setPartnerId($partner_id);

        
					$key_verify=($this->_dataHelper->getCommonConfigData('key_prod_verify', $storeId));
					$key_verify2=($this->_dataHelper->getCommonConfigData('key_test_verify', $storeId));
echo $key_verify;
echo '<br />';
echo $key_verify2;
exit();
         

        $amount=1;
        $amount_converted=($this->convertToBaseCurrency($amount,null,'AED'));

        $aed_amount=$amount_converted['value_for_aed'];
       


        // placeOrder
        $order_no = substr(md5(time()), 0, 20);
        try {
            // bizContent
            $or = \PayBy\Payment\Model\Api\Order::placeOrder(
                [
                    "merchantOrderNo" => $order_no,
                    "subject" => $order_no,
                    'totalAmount' => [
                        'currency' => 'AED',
                        'amount' => $aed_amount,
                    ],
                    "paySceneCode" => "PAYPAGE",
                    "paySceneParams"=>[
                        "redirectUrl"=>"http://m2235.jorigin.cn/payby/payment/notify"
                    ],
                    "notifyUrl" => "http://m2235.jorigin.cn/payby/payment/notify",
                   
                ]
            );
            print_r($or->body->interActionParams->tokenUrl);
        } catch (\PayBy\Payment\Model\Error\Base $e) {
            // 捕获报错信息
            echo 'error:';
            print_r($e);
        }




        /*
		$orderId="000000031";
		$order = $this->_objectManager->create('Magento\Sales\Model\Order');
		$order->loadByIncrementId($orderId);
		$storeId = $order->getStore()->getId(); 
        echo $this->_dataHelper->getCommonConfigData('platform_url', $storeId);
        
        */
	
	
        echo 'end';
        exit(); 
    }
}