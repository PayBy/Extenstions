<?php

/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
 *
 * @category  payment
 * @package   payby  
 * @copyright PayBy.com
 * @version   2.0.0 
 */

namespace PayBy\Payment\Controller\Payment;



use Magento\Framework\Exception\PaymentException;

use PayBy\Payment\Model\Error;


use Magento\Framework\App\CsrfAwareActionInterface;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\App\Request\InvalidRequestException;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Exception\RemoteServiceUnavailableException;
use Magento\Sales\Model\OrderFactory;

class Notify extends \PayBy\Payment\Controller\Payment implements CsrfAwareActionInterface
{
	/**
	 * @var \PayBy\Payment\Model\Api\PaybyResponseFactory
	 */
	protected $_paybyResponseFactory;

	/**
	 * @var OrderFactory
	 */
	private $orderFactory;

	/**
	 * @param \Magento\Framework\App\Action\Context $context
	 * @param \Magento\Store\Model\StoreManagerInterface $storeManager
	 * @param \PayBy\Payment\Helper\Data $dataHelper
	 * @param \PayBy\Payment\Helper\Payment $paymentHelper 
	 * @param \PayBy\Payment\Model\Api\PaybyResponseFactory $paybyResponseFactory
	 */
	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
		\PayBy\Payment\Helper\Data $dataHelper,
		\PayBy\Payment\Helper\Payment $paymentHelper,
		\Magento\Quote\Api\CartRepositoryInterface $quoteRepository,
		\PayBy\Payment\Model\Api\PaybyResponseFactory $paybyResponseFactory,
		OrderFactory $orderFactory = null
	) {
		$this->_paybyResponseFactory = $paybyResponseFactory;
		$this->orderFactory = $orderFactory ?: ObjectManager::getInstance()->get(OrderFactory::class);

		parent::__construct($context, $storeManager, $dataHelper, $paymentHelper, $quoteRepository);
	}


	/**
	 * @inheritDoc
	 */
	public function createCsrfValidationException(
		RequestInterface $request
	): ?InvalidRequestException {
		return null;
	}

	/**
	 * @inheritDoc
	 */
	public function validateForCsrf(RequestInterface $request): ?bool
	{
		return true;
	}

	public function execute()
	{
		$this->_dataHelper->log('Notify data:');
		if (!$this->getRequest()->isPost()) {
			$this->_dataHelper->log('Not post request and denied!');
			return;
		}
 

		$postData = @file_get_contents('php://input');


		$sign = '';
		if (isset($_SERVER['HTTP_SIGN'])) {
			$sign = $_SERVER['HTTP_SIGN'];
			$this->_dataHelper->log('Payment response sign : ' . print_r($sign, true));
		}   
   



		$this->_dataHelper->log('Payment response parameters : ' . print_r($postData, true));
 


		$bodyData = json_decode($postData, true);
		$this->_dataHelper->log('Payment response parameters json: ' . print_r($bodyData, true));

		if (isset($bodyData['acquireOrder']['merchantOrderNo'])) {

			$incrementId = $bodyData['acquireOrder']['merchantOrderNo'];
			$this->_dataHelper->log('order  id:' . $incrementId);
			$status = '';
			if (isset($bodyData['acquireOrder']['status'])) {
				$status = $bodyData['acquireOrder']['status'];
			}
			$order = $this->orderFactory->create()->loadByIncrementId($incrementId);
			if ($order->getId()) {
				$storeId = $order->getStore()->getId();      
				$this->_dataHelper->log('found order !' . $incrementId);
				$this->_dataHelper->log('status !' . $status);

				
				
				$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
				$storeManager = $objectManager->get('Magento\Store\Model\StoreManagerInterface');   
				$ctx_mode=$this->_dataHelper->getCommonConfigData('ctx_mode', $storeId);
				if($ctx_mode=='TEST'){
					\PayBy\Payment\Model\PayBy::$caBundle=__DIR__ . '/../../cert/cacert.pem'; 
					$key_verify=($this->_dataHelper->getCommonConfigData('key_test_verify', $storeId));
		
				}else{
					\PayBy\Payment\Model\PayBy::$caBundle=__DIR__ . '/../../cert/cacert.pem'; 
					$key_verify=($this->_dataHelper->getCommonConfigData('key_prod_verify', $storeId));
				}

				
				$signResult = openssl_verify($postData, base64_decode($sign) , $key_verify, OPENSSL_ALGO_SHA256);
				if (!$signResult) {
					$this->_dataHelper->log('Verify signature failed');
					// authentification failed
					$this->_dataHelper->log("{$this->_dataHelper->getIpAddress()} tries to access our payby/payment/return page without valid signature. It may be a hacking attempt.", \Psr\Log\LogLevel::ERROR);
					throw new Error\Api("Verify signature failed");
					echo 'ERROR';
					exit();
				}else{
					$this->_dataHelper->log('Verify signature success');

				}


				// get store id from order
				$paybyResponse = $this->_paybyResponseFactory->create([
					'params' => $bodyData,
					'ctx_mode' => $this->_dataHelper->getCommonConfigData('ctx_mode', $storeId),
					'key_test' => $this->_dataHelper->getCommonConfigData('key_test_verify', $storeId),
					'key_prod' => $this->_dataHelper->getCommonConfigData('key_prod_verify', $storeId)
				]);
 
				if ($order->getStatus() == 'pending_payment') {
					
					if ($status == 'PAID_SUCCESS') {
						$this->_dataHelper->log('PAID_SUCCESS !');

						$this->_paymentHelper->registerOrder($order, $paybyResponse);
						echo 'SUCCESS';
						$this->_dataHelper->log('invoice end !');
						exit();
					}
				}
			}
		}


		echo 'ERROR';
		exit(); 
	}
 
}
