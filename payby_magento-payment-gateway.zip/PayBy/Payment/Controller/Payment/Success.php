<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
 *
 * @category  payment
 * @package   payby  
 * @copyright PayBy.com
 * @version   2.0.0 
 */
namespace PayBy\Payment\Controller\Payment;




if (!function_exists('curl_init')) {
    throw new Exception('PayBy needs the CURL PHP extension.');
}
if (!function_exists('json_decode')) {
    throw new Exception('PayBy needs the JSON PHP extension.');
}
if (!function_exists('mb_detect_encoding')) {
    throw new Exception('PayBy needs the Multibyte String PHP extension.');
}
/*
// PayBy
require(dirname(__FILE__) . '/../../Model/PayBy.php');

// Utilities
require(dirname(__FILE__) . '/../../Model/Util/Util.php');
require(dirname(__FILE__) . '/../../Model/Util/Set.php');

// Errors
require(dirname(__FILE__) . '/../../Model/Error/Base.php');
require(dirname(__FILE__) . '/../../Model/Error/Api.php');
require(dirname(__FILE__) . '/../../Model/Error/ApiConnection.php');
require(dirname(__FILE__) . '/../../Model/Error/Authentication.php');
require(dirname(__FILE__) . '/../../Model/Error/InvalidRequest.php');

require(dirname(__FILE__) . '/../../Model/PayByObject.php');

// Api Base
require(dirname(__FILE__) . '/../../Model/Api/ApiRequestor.php');
require(dirname(__FILE__) . '/../../Model/Api/ApiResource.php');

// PayBy API Resources
require(dirname(__FILE__) . '/../../Model/Api/Order.php');

*/


class Success extends \PayBy\Payment\Controller\Payment
{
    /**
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry;
    protected $_priceHelper;

    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $_resultPageFactory;

    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \PayBy\Payment\Helper\Data $dataHelper
     * @param \PayBy\Payment\Helper\Payment $paymentHelper
     * @param \Magento\Quote\Api\CartRepositoryInterface $quoteRepository
     * @param \Magento\Framework\Registry $coreRegistry
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     */
    public function __construct(
            \Magento\Framework\App\Action\Context $context,
            \Magento\Store\Model\StoreManagerInterface $storeManager,
            \PayBy\Payment\Helper\Data $dataHelper,
            \PayBy\Payment\Helper\Payment $paymentHelper,
            \Magento\Quote\Api\CartRepositoryInterface $quoteRepository,
            \Magento\Framework\Registry $coreRegistry,
            \Magento\Framework\Pricing\Helper\Data $priceHelper,
            \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {
        $this->_coreRegistry = $coreRegistry;
        $this->_resultPageFactory = $resultPageFactory;
        $this->_priceHelper = $priceHelper;

        parent::__construct($context, $storeManager, $dataHelper, $paymentHelper, $quoteRepository);
    } 
    public function convertToBaseCurrency($amount = 0, $store = null, $currency = null)
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $priceCurrencyObject = $objectManager->get('Magento\Framework\Pricing\PriceCurrencyInterface'); 
        //instance of PriceCurrencyInterface
        $storeManager = $objectManager->get('Magento\Store\Model\StoreManagerInterface'); 
        //instance of StoreManagerInterface
        if ($store == null) {
            $store = $storeManager->getStore()->getStoreId(); 
            //get current store id if store id not get passed
        }
        $rate = $priceCurrencyObject->convert($amount, $store, $currency); 
        //it return price according to current store from base currency
        
      

        $formattedCurrencyValue = $this->_priceHelper->currencyByStore($amount,  $store, $format = false, $includeContainer = false);
        return array('value_for_aed'=>$rate,'value'=>$formattedCurrencyValue,'store'=>$store);


 
    
    }
    public function execute()
    { 

        echo 'success';

        /*
		$orderId="000000031";
		$order = $this->_objectManager->create('Magento\Sales\Model\Order');
		$order->loadByIncrementId($orderId);
		$storeId = $order->getStore()->getId(); 
        echo $this->_dataHelper->getCommonConfigData('platform_url', $storeId);
        
        */
	
	
        exit(); 
    }
}