<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
 *
 * @category  payment
 * @package   payby  
 * @copyright PayBy.com
 * @version   2.0.0 
 */
namespace PayBy\Payment\Block\Payment\Form;

class Standard extends Payby
{
	protected $_template = 'PayBy_Payment::payment/form/standard.phtml';

	public function getAvailableCcTypes()
	{
		return $this->getMethod()->getAvailableCcTypes();
	}

	public function getCcTypeNetwork($code)
	{
		if($code == 'AMEX') {
			return 'AMEX';
		} elseif(in_array($code, array('CB', 'VISA', 'VISA_ELECTRON', 'MASTERCARD', 'MAESTRO', 'E-CARTEBLEUE'))) {
			return 'CB';
		} else {
			return null;
		}
	}

	public function getCcTypeImageSrc($card)
	{
		$card = strtolower($card);

		$path = Mage::getBaseDir('media') . DS . 'payby' . DS . 'ct' . DS . $card . '.png';
		if (file_exists($path)) {
			return Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_MEDIA) . 'payby/ct/' . $card . '.png';
		} else {
			return false;
		}
	}

	public function isLocalCcInfo()
	{
		return $this->getMethod()->isLocalCcInfo();
	}

	public function isLocalCcType()
	{
		return $this->getMethod()->isLocalCcType();
	}
}