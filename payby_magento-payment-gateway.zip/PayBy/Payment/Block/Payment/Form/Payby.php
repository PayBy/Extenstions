<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
 *
 * @category  payment
 * @package   payby  
 * @copyright PayBy.com
 * @version   2.0.0 
 */
namespace PayBy\Payment\Block\Payment\Form;

abstract class Payby extends \Magento\Payment\Block\Form
{
	/**
	 * @var \PayBy\Payment\Helper\Data
	 */
	protected $_dataHelper;

	/**
	 * @param \Magento\Framework\View\Element\Template\Context $context
	 * @param \PayBy\Payment\Helper\Data $dataHelper
	 * @param array $data
	 */
	public function __construct(
			\Magento\Framework\View\Element\Template\Context $context,
			\PayBy\Payment\Helper\Data $dataHelper,
			array $data = []
	) {
		$this->_dataHelper = $dataHelper;

		parent::__construct($context, $data);
	}

	protected function _construct()
	{
		parent::_construct();

		$logoURL = $this->_checkAndGetLogoUrl($this->getConfigData('module_logo'));

		if(!$this->_dataHelper->isBackend() && $logoURL) {
			/** @var $logo Template */
			$logo = $this->_layout->createBlock('Magento\Framework\View\Element\Template');
			$logo->setTemplate('PayBy_Payment::payment/logo.phtml');
			$logo->setLogoUrl($logoURL);

			// add logo to the method title
			$this->setMethodLabelAfterHtml($logo->toHtml());
		}
	}

	private function _checkAndGetLogoUrl($fileName)
	{
		if (!$fileName) {
			return false;
		}

		if ($this->_dataHelper->isUploadFileImageExists($fileName)) {
			return $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA) . 'payby/images/' . $fileName;
		} else {
			return $this->getViewFileUrl('PayBy_Payment::images/' . $fileName);
		}
	}

	public function getConfigData($name)
	{
		return $this->getMethod()->getConfigData($name);
	}
}