<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
 *
 * @category  payment
 * @package   payby  
 * @copyright PayBy.com
 * @version   2.0.0 
 */
namespace PayBy\Payment\Block\Adminhtml\System\Config\Form\Field;

/**
 * Custom renderer for the Payby multi select fields.
 */
class Multiselect extends \Magento\Config\Block\System\Config\Form\Field
{
	/**
	 * Set field size.
	 *
	 * @param \Magento\Framework\Data\Form\Element\AbstractElement $element
	 * @return string
	 */
	public function render(\Magento\Framework\Data\Form\Element\AbstractElement $element)
	{
		$element->setSize(5);

		return parent::render($element);
	}
}