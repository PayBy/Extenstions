<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
 *
 * @category  payment
 * @package   payby  
 * @copyright PayBy.com
 * @version   2.0.0 
 */
namespace PayBy\Payment\Block\Adminhtml\System\Config\Form\Field;

/**
 * Custom renderer for the Payby sub-module logo.
 */
class Logo extends \Magento\Config\Block\System\Config\Form\Field
{
/**
	 * @var \PayBy\Payment\Helper\Data
	 */
	protected $_dataHelper;

	/**
	 * @param \Magento\Backend\Block\Template\Context $context
	 * @param \PayBy\Payment\Helper\Data $dataHelper
	 * @param array $data
	 */
	public function __construct(
			\Magento\Backend\Block\Template\Context $context,
			\PayBy\Payment\Helper\Data $dataHelper,
			$data = []
	) {
		$this->_dataHelper = $dataHelper;

		parent::__construct($context, $data);
	}

	/**
	 * Set default image URL.
	 *
	 * @param \Magento\Framework\Data\Form\Element\AbstractElement $element
	 * @return string
	 */
	public function render(\Magento\Framework\Data\Form\Element\AbstractElement $element)
	{
		$html = parent::render($element);

		$fileName = $element->getValue();
		if ($fileName && !$this->_dataHelper->isUploadFileImageExists($fileName)) {
			// default logo defined in the module
			$imgSrc = $this->getViewFileUrl('PayBy_Payment::images/' . $fileName);

			$html = preg_replace('#src="https?://[^"]+"#', 'src="' . $imgSrc . '"', $html);
		}

		return $html;
	}
}