<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
 *
 * @category  payment
 * @package   payby  
 * @copyright PayBy.com
 * @version   2.0.0 
 */
namespace PayBy\Payment\Controller\Payment;

use \PayBy\Payment\Model\Api\PaybyApi;

class Check extends \PayBy\Payment\Controller\Payment
{
	/**
	 * @var \PayBy\Payment\Model\Api\PaybyResponseFactory
	 */
	protected $_paybyResponseFactory;

	/**
	 * @param \Magento\Framework\App\Action\Context $context
	 * @param \Magento\Store\Model\StoreManagerInterface $storeManager
	 * @param \PayBy\Payment\Helper\Data $dataHelper
	 * @param \PayBy\Payment\Helper\Payment $paymentHelper
	 * @param \Magento\Quote\Api\CartRepositoryInterface $quoteRepository
	 * @param \PayBy\Payment\Model\Api\PaybyResponseFactory $paybyResponseFactory
	 */
	public function __construct(
			\Magento\Framework\App\Action\Context $context,
			\Magento\Store\Model\StoreManagerInterface $storeManager,
			\PayBy\Payment\Helper\Data $dataHelper,
			\PayBy\Payment\Helper\Payment $paymentHelper,
			\Magento\Quote\Api\CartRepositoryInterface $quoteRepository,
			\PayBy\Payment\Model\Api\PaybyResponseFactory $paybyResponseFactory
	) {
		$this->_paybyResponseFactory = $paybyResponseFactory;

		parent::__construct($context, $storeManager, $dataHelper, $paymentHelper, $quoteRepository);
	}

	public function execute()
	{
		if (!$this->getRequest()->isPost()) {
			return;
		}

		$post = $this->getRequest()->getParams();
		$this->_dataHelper->log('Payment response parameters : ' . print_r($post, true), \Psr\Log\LogLevel::DEBUG);

		// loading order
		$orderId = key_exists('vads_order_id', $post) ? $post['vads_order_id'] : 0;
		$order = $this->_objectManager->create('Magento\Sales\Model\Order');
		$order->loadByIncrementId($orderId);

		// get store id from order
		$storeId = $order->getStore()->getId();

		// init app with correct store id
		$this->_storeManager->setCurrentStore($storeId);

		// load API response
		$this->_dataHelper->log('Create PayBy\Payment\Model\Api\PaybyResponse object to manage platform response.');

		$paybyResponse = $this->_paybyResponseFactory->create([
				'params' => $post,
				'ctx_mode' => $this->_dataHelper->getCommonConfigData('ctx_mode', $storeId),
				'key_test' => $this->_dataHelper->getCommonConfigData('key_test', $storeId),
				'key_prod' => $this->_dataHelper->getCommonConfigData('key_prod', $storeId)
		]);

		if(!$paybyResponse->isAuthentified()) {
			// authentification failed
			$this->_dataHelper->log("{$this->_dataHelper->getIpAddress()} tries to access our payby/payment/check page without valid signature. It may be a hacking attempt.", \Psr\Log\LogLevel::WARNING);
			$this->getResponse()->setBody($paybyResponse->getOutputForPlatform('auth_fail'));
			return;
		}
		$this->_dataHelper->log('Request authenticated.');

		$reviewStatuses = array('payment_review', 'payby_to_validate', 'fraud');

		if($order->getStatus() == 'pending_payment' || in_array($order->getStatus(), $reviewStatuses)) {
			// order waiting for payment
			$this->_dataHelper->log("Order #{$order->getId()} is waiting payment.");

			if($paybyResponse->isAcceptedPayment()) {
				$this->_dataHelper->log("Payment for order #{$order->getId()} has been confirmed by notification URL.");

				// check if payment status has changed
				if(
						($order->getStatus() == 'fraud' && $paybyResponse->isSuspectedFraud()) ||
						($order->getStatus() == 'payby_to_validate' && $paybyResponse->isToValidatePayment()) ||
						($order->getStatus() == 'payment_review' && !$paybyResponse->isToValidatePayment() && $paybyResponse->isPendingPayment())
				) {
					// display notification url confirmation message
					$this->getResponse()->setBody($paybyResponse->getOutputForPlatform('payment_ok_already_done'));
				} else {
					// save order and optionally create invoice
					$this->_paymentHelper->registerOrder($order, $paybyResponse);

					// display notification url confirmation message
					$this->getResponse()->setBody($paybyResponse->getOutputForPlatform('payment_ok'));
				}
			} else {
				$this->_dataHelper->log("Payment for order #{$order->getId()} has been invalidated by notification URL.");

				// cancel order
				$this->_paymentHelper->cancelOrder($order, $paybyResponse);

				// display notification url failure message
				$this->getResponse()->setBody($paybyResponse->getOutputForPlatform('payment_ko'));
			}
		} else {
			// payment already processed

			$acceptedStatus = $this->_dataHelper->getCommonConfigData('registered_order_status', $storeId);
			$successStatuses = array(
					$acceptedStatus,
					'complete' /* case of virtual orders */
			);

			if($paybyResponse->isAcceptedPayment() && in_array($order->getStatus(), $successStatuses)) {
				$this->_dataHelper->log("Order #{$order->getId()} is confirmed.");

				if($paybyResponse->get('operation_type') == 'CREDIT') {
					// this is a refund

					$currency = PaybyApi::findCurrencyByNumCode($paybyResponse->get('currency'));

					$expiry = '';
					if($paybyResponse->get('expiry_month') && $paybyResponse->get('expiry_year')) {
						$expiry = str_pad($paybyResponse->get('expiry_month'), 2, '0', STR_PAD_LEFT) . ' / ' . $paybyResponse->get('expiry_year');
					}

					$transactionId = $paybyResponse->get('trans_id') . '-' . $paybyResponse->get('sequence_number');

					$additionalInfo = array(
							'Transaction Type' => 'CREDIT',
							'Amount' => round($currency->convertAmountToFloat($paybyResponse->get('amount')), $currency->getNum()) . ' ' . $currency->getAlpha3(),
							'Transaction ID' => $transactionId,
							'Transaction Status' => $paybyResponse->get('trans_status'),
							'Payment Mean' => $paybyResponse->get('card_brand'),
							'Card Number' => $paybyResponse->get('card_number'),
							'Expiration Date' => $expiry,
							'3-DS Certificate' => ''
					);

					$transactionType = \Magento\Sales\Model\Order\Payment\Transaction::TYPE_REFUND;

					$this->_paymentHelper->addTransaction($payment, $transactionType, $transactionId, $additionalInfo);
				} else {
					// update transaction info
					$this->_paymentHelper->updatePaymentInfo($order, $paybyResponse);
				}
				$order->save();

				$this->getResponse()->setBody($paybyResponse->getOutputForPlatform('payment_ok_already_done'));
			} elseif($order->isCanceled() && !$paybyResponse->isAcceptedPayment()) {
				$this->_dataHelper->log("Order #{$order->getId()} cancelation is confirmed.");
				$this->getResponse()->setBody($paybyResponse->getOutputForPlatform('payment_ko_already_done'));
			} else {
				// this is an error case, the client returns with an error code but the payment already has been accepted
				$this->_dataHelper->log("Order #{$order->getId()} has been validated but we receive a payment error code !", \Psr\Log\LogLevel::ERROR);
				$this->getResponse()->setBody($paybyResponse->getOutputForPlatform('payment_ko_on_order_ok'));
			}
		}
	}
}