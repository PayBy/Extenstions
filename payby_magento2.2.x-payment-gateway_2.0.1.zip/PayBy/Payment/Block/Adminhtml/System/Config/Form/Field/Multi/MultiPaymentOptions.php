<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
 *
 * @category  payment
 * @package   payby  
 * @copyright PayBy.com
 * @version   2.0.0 
 */
namespace PayBy\Payment\Block\Adminhtml\System\Config\Form\Field\Multi;

/**
 * Custom renderer for the Payby multi payment options field.
 */
class MultiPaymentOptions extends \PayBy\Payment\Block\Adminhtml\System\Config\Form\Field\FieldArray\ConfigFieldArray
{
	/**
	 * Prepare to render.
	 *
	 * @return void
	 */
	public function _prepareToRender()
	{
		$this->addColumn('label', [
				'label' => __('Label') . '<span style="color: red;">*</span>',
				'style' => 'width: 150px;',
		]);
		$this->addColumn('minimum', [
				'label' => __('Min. amount'),
				'style' => 'width: 80px;',
		]);
		$this->addColumn('maximum', [
				'label' => __('Max. amount'),
				'style' => 'width: 80px;',
		]);
		$this->addColumn('contract', [
				'label' => __('Contract'),
				'style' => 'width: 65px;',
		]);
		$this->addColumn('count', [
				'label' => __('Count') . '<span style="color: red;">*</span>',
				'style' => 'width: 65px;',
		]);
		$this->addColumn('period', [
				'label' => __('Period') . '<span style="color: red;">*</span>',
				'style' => 'width: 65px;',
		]);
		$this->addColumn('first', [
				'label' => __('1st payment'),
				'style' => 'width: 70px;',
		]);

		parent::_prepareToRender();
	}
}