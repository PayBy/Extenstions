<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
 *
 * @category  payment
 * @package   payby  
 * @copyright PayBy.com
 * @version   2.0.0 
 */
namespace PayBy\Payment\Block\Adminhtml\System\Config\Form\Field\FieldArray;

/**
 * Payby backend system config array field renderer.
 */
abstract class ConfigFieldArray extends \Magento\Config\Block\System\Config\Form\Field\FieldArray\AbstractFieldArray
{
	/**
	 * @var bool
	 */
	protected $_static = false;

	protected function _construct()
	{
		if ($this->_static) {
			$this->_template = 'PayBy_Payment::system/config/form/field/static_array.phtml';
		}
		$this->_addAfter = false;
		$this->_addButtonLabel = __('Add');

		parent::_construct();
	}

	/**
	 * Retrieve label type column renderer.
	 *
	 * @return Customergroup
	 */
	protected function _getLabelRenderer($columnName)
	{
		if (!isset($this->$columnName) || !$this->$columnName) {
			$this->$columnName = $this->getLayout()->createBlock(
					'PayBy\Payment\Block\Adminhtml\System\Config\Form\Field\Renderer\ColumnLabel',
					'',
					['data' => ['is_render_to_js_template' => false]]
			);
		}

		return $this->$columnName;
	}

	/**
	 * Retrieve list type column renderer.
	 *
	 * @return Customergroup
	 */
	protected function _getListRenderer($columnName, $options)
	{
		if (!isset($this->$columnName) || !$this->$columnName) {
			$this->$columnName = $this->getLayout()->createBlock(
					'PayBy\Payment\Block\Adminhtml\System\Config\Form\Field\Renderer\ColumnList',
					'',
					['data' => ['is_render_to_js_template' => false, 'options' => $options]]
			);
		}

		return $this->$columnName;
	}


	/**
	 * Retrieve list type column renderer.
	 *
	 * @return Customergroup
	 */
	protected function _getUploadButtonRenderer($columnName)
	{
		if (!isset($this->$columnName) || !$this->$columnName) {
			$this->$columnName = $this->getLayout()->createBlock(
					'PayBy\Payment\Block\Adminhtml\System\Config\Form\Field\Renderer\ColumnUploadButton',
					'',
					['data' => ['is_render_to_js_template' => false]]
			);
		}

		return $this->$columnName;
	}

	protected function _getDependsOnField() {
		return null;
	}

	protected function _getDependsOnValue() {
		return null;
	}

	/**
	 * Render HTML block.
	 *
	 * @return string
	 */
	protected function _toHtml()
	{
		$thisEltId = $this->getElement()->getId();

		$script = '
			<script type="text/javascript">
			//<![CDATA[
				 require([
					"prototype"
				], function () {
					var toggleHiddenValueElements = function () {
						setTimeout(function() {
							$$("#' . $thisEltId . ' tr td input[type=\"hidden\"]").each(function(elt) {
								var disabled = false;
								if ($("' . $thisEltId . '_inherit")) {
									disabled |= $("' . $thisEltId . '_inherit").checked;
								}
		';

		if($this->_getDependsOnField()) {
			$script .= '
								disabled |= $("' . $this->_getDependsOnField() . '").getValue() != "' . $this->_getDependsOnValue() . '";
			';
		}

		$script .= '
								elt.disabled = disabled;
							});
						}, 100);
					};


					toggleHiddenValueElements();
		';

		if($this->_getDependsOnField()) {
			$script .= '
					Event.observe($("' . $this->_getDependsOnField() . '"), "change", function() {
						toggleHiddenValueElements();

						setTimeout(function() {
							toggleValueElements($("' . $thisEltId . '_inherit"), $("' . $thisEltId . '").parentNode);
						}, 100);
					});
			';
		}

		$script .= '
					if ($("' . $thisEltId . '_inherit")) {
						Event.observe($("' . $thisEltId . '_inherit"), "change", function(inherit) {
							toggleHiddenValueElements();
						});
					}
				});
			//]]>
			</script>
		';

		return '<div id="' . $this->getElement()->getId() . '">' . parent::_toHtml() . "\n$script". '</div>';
	}
}