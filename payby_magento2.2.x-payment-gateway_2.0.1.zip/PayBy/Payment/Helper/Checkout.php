<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
 *
 * @category  payment
 * @package   payby  
 * @copyright PayBy.com
 * @version   2.0.0 
 */
namespace PayBy\Payment\Helper;

use PayBy\Payment\Model\Api\PaybyApi;

class Checkout
{
	const ORDER_ID_REGEX = '#^[a-zA-Z0-9]{1,9}$#';
	const CUST_ID_REGEX = '#^[a-zA-Z0-9]{1,8}$#';
	const PRODUCT_REF_REGEX = '#^[a-zA-Z0-9]{1,64}$#';

	/**
	 * @var \Magento\Framework\ObjectManagerInterface
	 */
	protected $_objectManager;

	/**
	 * @var \PayBy\Payment\Helper\Data
	 */
	protected $_dataHelper;

	/**
	 * @param \Magento\Framework\ObjectManagerInterface $objectManager
	 * @param \PayBy\Payment\Helper\Data $dataHelper
	 */
	public function __construct(
			\Magento\Framework\ObjectManagerInterface $objectManager,
			\PayBy\Payment\Helper\Data $dataHelper
	) {
		$this->_objectManager = $objectManager;
		$this->_dataHelper = $dataHelper;
	}

	/**
	 * Normalize shipping method name.
	 *
	 * @param string $name
	 * @return string normalized name
	 */
	public function cleanShippingMethod($name)
	{
		$notAllowed = "#[^A-ZÇ0-9ÁÀÂÄÉÈÊËÍÌÎÏÓÒÔÖÚÙÛÜÇ /'-]#ui";
		return preg_replace($notAllowed, '', $name);
	}

	public function checkCustormers($scope, $scopeId)
	{
		// check customer IDs
		$collection = Mage::getModel('customer/customer')->getCollection();

		if($scope == 'websites') {
			$collection->addAttributeToFilter('website_id', $scopeId);
		} elseif($scope == 'stores') {
			$collection->addAttributeToFilter('store_id', $scopeId);
		}
		$collection->load();

		foreach ($collection as $customer) {
			if(!preg_match(self::CUST_ID_REGEX, $customer->getId())) {
				// a customer id doesn't match Payby rules

				$msg = '';
				$msg .= __('Customer ID &laquo;%1&raquo; does not match Payby specifications.', $customer->getId()) . ' ';
				$msg .= __('This field must agree to the regular expression %1.', self::CUST_ID_REGEX);

				Mage::throwException($msg);
			}
		}
	}

	public function checkOrders($scope, $scopeId)
	{
		// check order IDs
		if($scope == 'stores') {
			// store context
			$incrementId = Mage::getSingleton('eav/config')->getEntityType('order')->fetchNewIncrementId($scopeId);

			$this->_checkOrderId($incrementId);
		} else {
			// general and website context
			$stores = Mage::app()->getStores();

			foreach ($stores as $store) {
				if($scope == 'websites' && $store->getWebsiteId() != $scopeId) {
					continue;
				}

				$incrementId = Mage::getSingleton('eav/config')->getEntityType('order')->fetchNewIncrementId($store->getId());
				$this->_checkOrderId($incrementId);
			}
		}
	}

	private function _checkOrderId($orderId)
	{
		if(!preg_match(self::ORDER_ID_REGEX, $orderId)) {
			// the potential next order id doesn't match Payby rules

			$msg = '';
			$msg .= __('The next order ID  &laquo;%1&raquo; does not match Payby specifications.', $orderId) . ' ';
			$msg .= __('This field must agree to the regular expression %1.', self::ORDER_ID_REGEX);

			Mage::throwException($msg);
		}
	}

	public function checkProducts($scope, $scopeId)
	{
		// check products' IDs and labels
		$collection = Mage::getModel('catalog/product')->getCollection();
		$collection->addAttributeToSelect('name');

		if($scope == 'websites') {
			$collection->addWebsiteFilter($scopeId);
		} elseif($scope == 'stores') {
			$collection->addStoreFilter($scopeId);
		}
		$collection->load();

		foreach ($collection as $product) {
			if(!preg_match(self::PRODUCT_REF_REGEX, $product->getId())) {
				// product id doesn't match Payby rules

				$msg = '';
				$msg .= __('Product reference &laquo;%1&raquo; does not match Payby specifications.', $product->getId()) . ' ';
				$msg .= __('This field must agree to the regular expression %1.', self::PRODUCT_REF_REGEX);

				Mage::throwException($msg);
			}
		}
	}

	public function checkOneyRequirements($scope, $scopeId)
	{
		$this->checkOrders($scope, $scopeId);
		$this->checkCustormers($scope, $scopeId);
		$this->checkProducts($scope, $scopeId);
	}

	public function toOneyCarrier($methodCode)
	{
		$shippingMapping = unserialize($this->_dataHelper->getCommonConfigData('ship_options'));

		if(is_array($shippingMapping) && count($shippingMapping) > 0) {
			foreach ($shippingMapping as $id => $shippingMethod) {
				if($shippingMethod['code'] === $methodCode) {
					return $shippingMethod;
				}
			}
		}

		return null;
	}

	public function toPaybyCategory($categoryIds)
	{
		// commmon category if any
		$commonCategory = $this->_dataHelper->getCommonConfigData('common_category');
		if($commonCategory != 'CUSTOM_MAPPING') {
			return $commonCategory;
		}

		$categoryMapping = unserialize($this->_dataHelper->getCommonConfigData('category_mapping'));

		if(is_array($categoryMapping) && count($categoryMapping) > 0 && is_array($categoryIds) && count($categoryIds) > 0) {
			foreach ($categoryMapping as $id => $category) {
				if(in_array($category['code'], $categoryIds)) {
					return $category['payby_category'];
				}
			}
		}

		return null;
	}

	public function setCartData($order, &$paybyRequest)
	{
		$notAllowed = '#[^A-Z0-9ÁÀÂÄÉÈÊËÍÌÎÏÓÒÔÖÚÙÛÜÇ ]#ui';

		// used currency
		$currency = PaybyApi::findCurrencyByNumCode($paybyRequest->get('currency'));

		// load all products in the shopping cart
		foreach ($order->getAllItems() as $item) {
			// check to avoid sending the whole hierarchy of a configurable product
			if (!$item->getParentItem()) {
				$product = $item->getProduct();
				if(!$product) {
					// load product instance
					$product = $this->_objectManager->create('Magento\Catalog\Model\Product')->load($item->getProductId());
				}

				$label = $item->getName();

				// concat product label with one or two of its category names to make it clearer
				$categoryIds = $product->getCategoryIds();
				if(is_array($categoryIds) && count($categoryIds)) {
					if(isset($categoryIds[1]) && $categoryIds[1]) {
						$category = $this->_objectManager->create('Magento\Catalog\Model\Category')->load($categoryIds[1]);
						$label = $category->getName() . ' I ' . $label;
					}

					if($categoryIds[0]) {
						$category = $this->_objectManager->create('Magento\Catalog\Model\Category')->load($categoryIds[0]);
						$label = $category->getName() . ' I ' . $label;
					}
				}

				$paybyRequest->addProduct(
						preg_replace($notAllowed, ' ', $label),
						$currency->convertAmountToInteger($item->getPrice()),
						(int)$item->getQtyOrdered(),
						$item->getProductId(),
						$this->toPaybyCategory($product->getCategoryIds())
				);
			}
		}
	}

	public function setOneyData($order, &$paybyRequest)
	{
		// by default, clients are private
		$paybyRequest->set('cust_status', 'PRIVATE');
		$paybyRequest->set('ship_to_status', 'PRIVATE');

		if($order->getIsVirtual() || !$order->getShippingMethod()) { // there is no shipping mean
			// set store name after illegal characters replacement
			$shopNameRegexNotAllowed = "#[^A-Z0-9ÁÀÂÄÉÈÊËÍÌÎÏÓÒÔÖÚÙÛÜÇ /'-]#ui";
			$paybyRequest->set('ship_to_delivery_company_name', preg_replace($shopNameRegexNotAllowed, ' ', Mage::app()->getStore()->getFrontendName()));
			$paybyRequest->set('ship_to_type', 'ETICKET');
			$paybyRequest->set('ship_to_speed', 'EXPRESS');
		} else {
			$shippingMethod = $this->toOneyCarrier($order->getShippingMethod());

			switch ($shippingMethod['type']) {
				case 'RECLAIM_IN_SHOP' :
				case 'RELAY_POINT':
				case 'RECLAIM_IN_STATION' :
					// it's recommended to put a specific logic here

					$address = ''; // initialize with selected SHOP/RELAY POINT/STATION name
					$address .= $order->getShippingAddress()->getStreet(1) . ' ';
					$address .= $order->getShippingAddress()->getStreet(2) ? $order->getShippingAddress()->getStreet(2) . ' ' : '';
					$address .= $order->getShippingAddress()->getPostcode() . ' ';
					$address .= $order->getShippingAddress()->getCity();

					// delete not allowed chars
					$shipAddressRegexNotAllowed = "#[^A-Z0-9ÁÀÂÄÉÈÊËÍÌÎÏÓÒÔÖÚÙÛÜÇ /'-]#ui";
					$address = preg_replace($shipAddressRegexNotAllowed, ' ', $address);

					$paybyRequest->set('ship_to_delivery_company_name', $shippingMethod['oney_label'] . ' ' . $address);
					break;
				default :
					$paybyRequest->set('ship_to_delivery_company_name', $shippingMethod['oney_label']);
					break;
			}

			$paybyRequest->set('ship_to_type', $shippingMethod['type']);
			$paybyRequest->set('ship_to_speed', $shippingMethod['speed']);
		}
	}

	public function setPaypalData($order, &$paybyRequest)
	{
		// used currency
		$currency = PaybyApi::findCurrencyByNumCode($paybyRequest->get('currency'));

		$subtotal = 0;
		for ($index=0; $index < $paybyRequest->get('nb_products'); $index++) {
			$subtotal += $paybyRequest->get('product_amount' . $index) * $paybyRequest->get('product_qty' . $index);
		}

		$paybyRequest->set('insurance_amount', 0); // by default, shipping insurance amount is not available in Magento
		$paybyRequest->set('shipping_amount', $currency->convertAmountToInteger($order->getShippingAmount()));

		// recalculate tax_amount to avoid rounding problems
		$taxAmount = $paybyRequest->get('amount') - $subtotal - $paybyRequest->get('shipping_amount') - $paybyRequest->get('insurance_amount');
		if($taxAmount <= 0) { // when order is discounted
			$taxAmount = $currency->convertAmountToInteger($order->getTaxAmount());
		}

		$paybyRequest->set('tax_amount', $taxAmount);
	}

	public function checkAddressValidity($address)
	{
		if(!$address) {
			return;
		}

		// oney validation regular expressions
		$nameRegex = "#^[A-ZÁÀÂÄÉÈÊËÍÌÎÏÓÒÔÖÚÙÛÜÇ/ '-]{1,63}$#ui";
		$phoneRegex = "#^[0-9]{10}$#";
		$cityRegex = "#^[A-Z0-9ÁÀÂÄÉÈÊËÍÌÎÏÓÒÔÖÚÙÛÜÇ/ '-]{1,127}$#ui";
		$streetRegex = "#^[A-Z0-9ÁÀÂÄÉÈÊËÍÌÎÏÓÒÔÖÚÙÛÜÇ/ '.,-]{1,127}$#ui";
		$countryRegex = "#^FR$#i";
		$zipRegex = "#^[0-9]{5}$#";

		// error messages
		$invalidMsg = 'The field %1 of your %2 is invalid.';
		$emptyMsg = 'The field %1 of your %2 is mandatory.';

		// address type
		$addressType = ($address->getAddressType() === 'billing') ? 'billing address' : 'delivery address';

		if(!$address->getLastname()) {
			$this->_throwException($emptyMsg, 'Last Name', $addressType);
		} elseif(!preg_match($nameRegex, $address->getLastname())) {
			$this->_throwException($invalidMsg, 'Last Name', $addressType);
		} elseif(!$address->getFirstname()) {
			$this->_throwException($emptyMsg, 'First Name', $addressType);
		} elseif(!preg_match($nameRegex, $address->getFirstname())) {
			$this->_throwException($invalidMsg, 'First Name', $addressType);
		} elseif($address->getTelephone() && !preg_match($phoneRegex, $address->getTelephone())) {
			$this->_throwException($invalidMsg, 'Telephone', $addressType);
		} elseif(!$address->getStreet(1)) {
			$this->_throwException($emptyMsg, 'Address', $addressType);
		} elseif(!preg_match($streetRegex, $address->getStreet(1))) {
			$this->_throwException($invalidMsg, 'Address', $addressType);
		} elseif($address->getStreet(2) && !preg_match($streetRegex, $address->getStreet(2))) {
			$this->_throwException($invalidMsg, 'Address', $addressType);
		} elseif(!$address->getPostcode()) {
			$this->_throwException($emptyMsg, 'Postcode', $addressType);
		} elseif(!preg_match($zipRegex, $address->getPostcode())) {
			$this->_throwException($invalidMsg, 'Postcode', $addressType);
		} elseif(!$address->getCity()) {
			$this->_throwException($emptyMsg, 'City', $addressType);
		} elseif(!preg_match($cityRegex, $address->getCity())) {
			$this->_throwException($invalidMsg, 'City', $addressType);
		} elseif(!$address->getCountryId()) {
			$this->_throwException($emptyMsg, 'Country', $addressType);
		} elseif(!preg_match($countryRegex, $address->getCountryId())) {
			$this->_throwException($invalidMsg, 'Country', $addressType);
		}
	}

	private function _throwException($msg, $field, $addressType)
	{
		// translate
		$field = __($field);
		$addressType = __($addressType);

		Mage::throwException(__($msg, $field, $addressType));
	}
}