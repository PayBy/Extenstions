<?php
/**
  * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
 *
 * @category  payment
 * @package   payby  
 * @copyright PayBy.com
 * @version   2.0.0 
 */
namespace PayBy\Payment\Helper\Payment;

use Magento\Framework\View\LayoutFactory;

class Data extends \Magento\Payment\Helper\Data
{
	/**
	 * @var \PayBy\Payment\Helper\Data
	 */
	protected $_dataHelper;

	/**
	 * Construct
	 *
	 * @param \Magento\Framework\App\Helper\Context $context
	 * @param LayoutFactory $layoutFactory
	 * @param \Magento\Payment\Model\Method\Factory $paymentMethodFactory
	 * @param \Magento\Store\Model\App\Emulation $appEmulation
	 * @param \Magento\Payment\Model\Config $paymentConfig
	 * @param \Magento\Framework\App\Config\Initial $initialConfig
	 * @param \PayBy\Payment\Helper\Data $dataHelper
	 */
	public function __construct(
			\Magento\Framework\App\Helper\Context $context,
			LayoutFactory $layoutFactory,
			\Magento\Payment\Model\Method\Factory $paymentMethodFactory,
			\Magento\Store\Model\App\Emulation $appEmulation,
			\Magento\Payment\Model\Config $paymentConfig,
			\Magento\Framework\App\Config\Initial $initialConfig,
			\PayBy\Payment\Helper\Data $dataHelper
	) {
		parent::__construct($context, $layoutFactory, $paymentMethodFactory, $appEmulation, $paymentConfig, $initialConfig);

		$this->_dataHelper = $dataHelper;
	}

	/**
	 * Retrieve all payment methods.
	 *
	 * @return array
	 */
	public function getPaymentMethods()
	{
		$methods = parent::getPaymentMethods();
  

		return $methods;
	}
}