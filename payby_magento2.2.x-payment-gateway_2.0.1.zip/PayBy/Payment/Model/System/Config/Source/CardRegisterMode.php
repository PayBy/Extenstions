<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
  
 * @category  payment
 * @package   payby

 * @copyright  2020
 * @license      Commercial License 
 * @version   2.0.0 
 */
namespace PayBy\Payment\Model\System\Config\Source;

class CardRegisterMode implements \Magento\Framework\Option\ArrayInterface
{
	public function toOptionArray()
	{
		return [
				['value' => '1', 'label' => __('Registration off by default')],
				['value' => '2', 'label' => __('Registration on by default')],
				['value' => '3', 'label' => __('Registration always on')]
		];
	}
}