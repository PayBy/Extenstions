<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
  
 * @category  payment
 * @package   payby

 * @copyright  2020
 * @license      Commercial License 
 * @version   2.0.0 
 */
namespace PayBy\Payment\Model\System\Config\Backend\Standard;

class CardInfoModes extends \Magento\Framework\App\Config\Value
{
	private $error = false;

	public function save()
	{
		$value = $this->getValue();

		if($value == 3 && !$this->_isFrontSecure()) {
			$this->error = true;
			$this->setValue(1);
		}

		return parent::save();
	}

	public function afterCommitCallback()
	{
		if($this->error) {
			throw new \Magento\Framework\Exception\LocalizedException(__('The card data entry on merchant site cannot be used without enabling SSL.'));
		}

		return parent::afterCommitCallback();
	}

	private function _isFrontSecure()
	{
		return $this->_config->isSetFlag(
				\Magento\Store\Model\Store::XML_PATH_SECURE_IN_FRONTEND,
				$this->getScope(),
				$this->getScopeId()
		);
	}
}