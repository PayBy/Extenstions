<?php

namespace PayBy\Payment\Model\Error;

class Api extends Base
{
}
