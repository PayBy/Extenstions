<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
 *
 * @category  payment
 * @package   payby  
 * @copyright PayBy.com
 * @version   2.0.0 
 */
namespace PayBy\Payment\Controller\Payment;

class Response extends \PayBy\Payment\Controller\Payment
{
	/**
	 * @var \PayBy\Payment\Model\Api\PaybyResponseFactory
	 */
	protected $_paybyResponseFactory;

	/**
	 * @param \Magento\Framework\App\Action\Context $context
	 * @param \Magento\Store\Model\StoreManagerInterface $storeManager
	 * @param \PayBy\Payment\Helper\Data $dataHelper
	 * @param \PayBy\Payment\Helper\Payment $paymentHelper
	 * @param \Magento\Quote\Api\CartRepositoryInterface $quoteRepository
	 * @param \PayBy\Payment\Model\Api\PaybyResponseFactory $paybyResponseFactory
	 */
	public function __construct(
			\Magento\Framework\App\Action\Context $context,
			\Magento\Store\Model\StoreManagerInterface $storeManager,
			\PayBy\Payment\Helper\Data $dataHelper,
			\PayBy\Payment\Helper\Payment $paymentHelper,
			\Magento\Quote\Api\CartRepositoryInterface $quoteRepository,
			\PayBy\Payment\Model\Api\PaybyResponseFactory $paybyResponseFactory
	) {
		$this->_paybyResponseFactory = $paybyResponseFactory;

		parent::__construct($context, $storeManager, $dataHelper, $paymentHelper, $quoteRepository);
	}

	public function execute()
	{
		$this->_dataHelper->log('Request test.');
		$request = $this->getRequest()->getParams();
		$this->_dataHelper->log('Payment response parameters : ' . print_r($request, true), \Psr\Log\LogLevel::DEBUG);
		$postData=$request;


		$orderId = key_exists('out_trade_no', $request) ? $request['out_trade_no'] : 0;
		if($orderId){
			$order = $this->_objectManager->create('Magento\Sales\Model\Order');
			$order->loadByIncrementId($orderId);
			
			if($order->getId()){
				$storeId = $order->getStore()->getId();
				$security_code=$this->_dataHelper->getCommonConfigData('key_prod', $storeId);
				$partner=$this->_dataHelper->getCommonConfigData('site_id', $storeId);
				$gateway=$this->_dataHelper->getCommonConfigData('platform_url', $storeId);
				 
				$sign_type='MD5';
				$mysign="";
				$_input_charset='utf-8'; 
				

				$veryfy_url = $gateway. "service=notify_verify" ."&partner=" .$partner. "&notify_id=".$postData["notify_id"];
				

				$veryfy_result="";
				$veryfy_result  = $this->get_verify($veryfy_url);
				
				$post           = $this->para_filter($postData);
				
				
				$sort_post      = $this->arg_sort($post);
				
				$arg="";
				while (list ($key, $val) = each ($sort_post)) {
				
					$arg.=$key."=".$val."&";
				}
				$prestr="";
				$prestr = substr($arg,0,count($arg)-2);  //去掉最后一个&号
				$mysign = $this->sign($prestr.$security_code);


				if ( $mysign == $postData["sign"])  {
					if($postData['trade_status'] == 'TRADE_FINISHED' || $postData['trade_status'] == 'TRADE_SUCCESS') {   
						if($order->getStatus() == 'pending_payment') {

							// get store id from order
							$paybyResponse = $this->_paybyResponseFactory->create([
									'params' => $request,
									'ctx_mode' => $this->_dataHelper->getCommonConfigData('ctx_mode', $storeId),
									'key_test' => $this->_dataHelper->getCommonConfigData('key_test', $storeId),
									'key_prod' => $this->_dataHelper->getCommonConfigData('key_prod', $storeId)
							]);
							$this->_paymentHelper->registerOrder($order, $paybyResponse);
							echo 'success';
							exit();
						}
					}

				}  
			}

		}
		
		echo 'error';
		exit();




		$this->_dataHelper->log('Payment response parameters : ' . print_r($request, true), \Psr\Log\LogLevel::DEBUG);

		// loading order
		$orderId = key_exists('vads_order_id', $request) ? $request['vads_order_id'] : 0;
		$order = $this->_objectManager->create('Magento\Sales\Model\Order');
		$order->loadByIncrementId($orderId);

		// get store id from order
		$storeId = $order->getStore()->getId();

		// load API response
		$this->_dataHelper->log('Create PayBy\Payment\Model\Api\PaybyResponse object to manage platform response.');

		$paybyResponse = $this->_paybyResponseFactory->create([
				'params' => $request,
				'ctx_mode' => $this->_dataHelper->getCommonConfigData('ctx_mode', $storeId),
				'key_test' => $this->_dataHelper->getCommonConfigData('key_test', $storeId),
				'key_prod' => $this->_dataHelper->getCommonConfigData('key_prod', $storeId)
		]);

		if(!$paybyResponse->isAuthentified()) {
			// authentification failed
			$this->_dataHelper->log("{$this->_dataHelper->getIpAddress()} tries to access our payby/payment/return page without valid signature. It may be a hacking attempt.", \Psr\Log\LogLevel::ERROR);
			$this->_redirectError($order);
			return;
		}

		$this->_dataHelper->log('Request authenticated.');

		if($order->getStatus() == 'pending_payment') {
			// order waiting for payment
			$this->_dataHelper->log("Order #{$order->getId()} is waiting payment.");

			if ($paybyResponse->isAcceptedPayment()) {
				$this->_dataHelper->log("Payment for order #{$order->getId()} has been confirmed by client return ! This means the notification URL did not work.", \Psr\Log\LogLevel::WARNING);

				// save order and optionally create invoice
				$this->_paymentHelper->registerOrder($order, $paybyResponse);

				// display success page
				$this->_redirectResponse($order, true /* is success ? */, true /* notification url warn in TEST mode */);
			} else {
				$this->_dataHelper->log("Payment for order #{$order->getId()} has failed.");

				// cancel order
				$this->_paymentHelper->cancelOrder($order, $paybyResponse);

				// redirect to cart page
				$this->_redirectResponse($order, false /* is success ? */);
			}
		} else {
			// payment already processed
			$this->_dataHelper->log("Order #{$order->getId()} has already been processed.");

			$acceptedStatus = $this->_dataHelper->getCommonConfigData('registered_order_status', $storeId);
			$successStatuses = array(
					$acceptedStatus,
					'complete' /* case of virtual orders */,
					'payment_review' /* case of pending payments like Oney */,
					'fraud' /* fraud status is taken as successful because it's just a suspicion */,
					'payby_to_validate' /* payment will be done after manual validation */
			);

			if($paybyResponse->isAcceptedPayment() && in_array($order->getStatus(), $successStatuses)) {
				$this->_dataHelper->log("Order #{$order->getId()} is confirmed.");
				$this->_redirectResponse($order, true /* is success ? */);

			} elseif($order->isCanceled() && !$paybyResponse->isAcceptedPayment()) {
				$this->_dataHelper->log("Order #{$order->getId()} cancelation is confirmed.");
				$this->_redirectResponse($order, false /* is success ? */);

			} else {
				// this is an error case, the client returns with an error code but the payment already has been accepted
				$this->_dataHelper->log("Order #{$order->getId()} has been validated but we receive a payment error code !", \Psr\Log\LogLevel::ERROR);
				$this->_redirectError($order);
			}
		}
	}

	public function get_verify($url,$time_out = "60") {
		$urlarr     = parse_url($url);
		$errno      = "";
		$errstr     = "";
		$transports = "";
		if($urlarr["scheme"] == "https") {
			$transports = "ssl://";
			$urlarr["port"] = "443";
		} else {
			$transports = "tcp://";
			$urlarr["port"] = "80";
		}
		$fp=@fsockopen($transports . $urlarr['host'],$urlarr['port'],$errno,$errstr,$time_out);
		if(!$fp) {
			die("ERROR: $errno - $errstr<br />\n");
		} else {
			fputs($fp, "POST ".$urlarr["path"]." HTTP/1.1\r\n");
			fputs($fp, "Host: ".$urlarr["host"]."\r\n");
			fputs($fp, "Content-type: application/x-www-form-urlencoded\r\n");
			fputs($fp, "Content-length: ".strlen($urlarr["query"])."\r\n");
			fputs($fp, "Connection: close\r\n\r\n");
			fputs($fp, $urlarr["query"] . "\r\n\r\n");
			while(!feof($fp)) {
				$info[]=@fgets($fp, 1024);
			}
			fclose($fp);
			$info = implode(",",$info);
			$arg="";
			while (list ($key, $val) = each ($_POST)) {
				$arg.=$key."=".$val."&";
			}

		return $info;
		}

	}

    
	public function sign($prestr) {
		$mysign = md5($prestr);
		return $mysign;
	}
    
	public function para_filter($parameter) {
		$para = array();
		while (list ($key, $val) = each ($parameter)) {
			if($key == "sign" || $key == "sign_type" || $val == "")continue;
			else	$para[$key] = $parameter[$key];

		}
		return $para;
	}
	
	public function arg_sort($array) {
		ksort($array);
		reset($array);
		return $array;
	}

	public function charset_encode($input,$_output_charset ,$_input_charset ="GBK" ) {
		
		$output = "";
		if($_input_charset == $_output_charset || $input ==null) {
			$output = $input;
		} elseif (function_exists("mb_convert_encoding")){
			$output = mb_convert_encoding($input,$_output_charset,$_input_charset);
		} elseif(function_exists("iconv")) {
			$output = iconv($_input_charset,$_output_charset,$input);
		} else die("sorry, you have no libs support for charset change.");
		
		return $output;
	}	

}