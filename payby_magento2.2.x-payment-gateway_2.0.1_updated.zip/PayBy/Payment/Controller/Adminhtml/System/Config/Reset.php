<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
 *
 * @category  payment
 * @package   payby  
 * @copyright PayBy.com
 * @version   2.0.0 
*/
namespace PayBy\Payment\Controller\Adminhtml\System\Config;

/**
 * Payby admin configuraion controller.
 */
class Reset extends \Magento\Backend\App\AbstractAction
{
	/**
	 * @var \Magento\Config\Model\ResourceModel\Config
	 */
	protected $_resourceConfig;

	/**
	 * @var \Magento\Framework\Cache\FrontendInterface
	 */
	protected $_cache;

	/**
	 * @param \Magento\Backend\App\Action\Context $context
	 * @param \Magento\Config\Model\ResourceModel\Config $resourceConfig
	 * @param \Magento\Framework\Cache\FrontendInterface $cache
	 */
	public function __construct(
			\Magento\Backend\App\Action\Context $context,
			\Magento\Config\Model\ResourceModel\Config $resourceConfig,
			\Magento\Framework\Cache\FrontendInterface $cache
	) {
		parent::__construct($context);

		$this->_resourceConfig = $resourceConfig;
		$this->_cache = $cache;
	}

	public function execute()
	{
		// retrieve write connection
		$connection = $this->_resourceConfig->getConnection();

		// get config_data model table name & execute query
		$query = "DELETE FROM `{$this->_resourceConfig->getMainTable()}` WHERE `path` LIKE 'payment/payby%' OR `path` LIKE 'payby/general/%'";
		$connection->query($query);

		// clear cache
		$this->_cache->clean();

		$this->messageManager->addSuccess(__('The configuration of the Payby module has been successfully reset.'));

		// redirect to payment config editor
		/** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
		$resultRedirect = $this->resultRedirectFactory->create();
		return $resultRedirect->setPath(
				'adminhtml/system_config/edit',
				[
						'section' => 'payment',
						'_nosid' => true
				]
		);
	}
}