/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
  
 * @category  payment
 * @package   payby

 * @copyright  2020
 * @license      Commercial License 
 * @version   2.0.0 
 */

define(
	[
		'uiComponent',
		'Magento_Checkout/js/model/payment/renderer-list'
	],
	function (
		Component,
		rendererList
	) {
		'use strict';
		rendererList.push(
			{
				type: 'payby_standard',
				component: 'PayBy_Payment/js/view/payment/method-renderer/payby-standard'
			} 
		);

		/** Add view logic here if needed */
		return Component.extend({});
	}
);