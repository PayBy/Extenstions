<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
 *
 * @category  payment
 * @package   payby  
 * @copyright PayBy.com
 * @version   2.0.0 
 */
namespace PayBy\Payment\Helper;

use Magento\Store\Model\ScopeInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Sales\Model\Order;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
	const METHOD_STANDARD = 'payby_standard';
	const METHOD_MULTI = 'payby_multi';
	const METHOD_GIFT = 'payby_gift';
	const METHOD_COF3XCB = 'payby_cof3xcb';
	const METHOD_ONEY = 'payby_oney';
	const METHOD_PAYPAL = 'payby_paypal';
	const METHOD_SOFORT = 'payby_sofort';
	const METHOD_POSTFINANCE = 'payby_postfinance';

	/**
	 * @var \Magento\Framework\ObjectManagerInterface
	 */
	protected $_objectManager;

	/**
	 * @var \Magento\Store\Model\StoreManagerInterface
	 */
	protected $_storeManager;

	/**
	 * @var \Magento\Framework\App\MaintenanceMode
	 */
	protected $_maintenanceMode;

	/**
	 * @var \Magento\Config\Model\ResourceModel\Config
	 */
	protected $_resourceConfig;

	/**
	 * @var \Magento\Framework\Filesystem
	 */
	protected $_filesystem;

	/**
	 * @var \Magento\Config\Model\Config\Structure
	 */
	protected $_configStructure;

	/**
	 * @var \PayBy\Payment\Model\Logger\Payby
	 */
	protected $_logger;

	/**
	 * @param \Magento\Framework\App\Helper\Context $context
	 * @param \Magento\Framework\ObjectManagerInterface $objectManager
	 * @param \Magento\Store\Model\StoreManagerInterface $storeManager
	 * @param \Magento\Framework\App\MaintenanceMode $maintenanceMode
	 * @param \Magento\Config\Model\ResourceModel\Config $resourceConfig
	 * @param \Magento\Framework\Filesystem $filesystem
	 * @param \Magento\Config\Model\Config\Structure $configStructure
	 * @param \PayBy\Payment\Model\Logger\Payby
	 */
	public function __construct(
			\Magento\Framework\App\Helper\Context $context,
			\Magento\Framework\ObjectManagerInterface $objectManager,
			\Magento\Store\Model\StoreManagerInterface $storeManager,
			\Magento\Framework\App\MaintenanceMode $maintenanceMode,
			\Magento\Config\Model\ResourceModel\Config $resourceConfig,
			\Magento\Framework\Filesystem $filesystem,
			\Magento\Config\Model\Config\Structure $configStructure,
			\PayBy\Payment\Model\Logger\Payby $logger
	) {
		parent::__construct($context);

		$this->_objectManager = $objectManager;
		$this->_storeManager = $storeManager;
		$this->_maintenanceMode = $maintenanceMode;
		$this->_resourceConfig = $resourceConfig;
		$this->_filesystem = $filesystem;
		$this->_configStructure = $configStructure;
		$this->_logger = $logger;
	}

	/**
	 * Shortcut method to get general Payby module configuration.
	 *
	 * @param string $field
	 * @param int|string|null|\Magento\Store\Model\Store $storeId
	 * @return mixed
	 */
	public function getCommonConfigData($field, $storeId=null)
	{
		if(is_null($storeId) && $this->isBackend()) {
			$storeId = $this->getCheckoutStoreId();
		}

		return $this->scopeConfig->getValue('payby/general/' . $field, ScopeInterface::SCOPE_STORE, $storeId);
	}

	/**
	 *  Return user's IP Address.
	 *
	 *  @return string
	 */
	public function getIpAddress()
	{
		if (isset($_SERVER)) {
			if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
				$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
			} elseif (isset($_SERVER['HTTP_CLIENT_IP'])) {
				$ip = $_SERVER['HTTP_CLIENT_IP'];
			} else {
				$ip = $_SERVER['REMOTE_ADDR'];
			}
		} else {
			if (getenv('HTTP_X_FORWARDED_FOR')) {
				$ip = getenv('HTTP_X_FORWARDED_FOR');
			} elseif (getenv('HTTP_CLIENT_IP')) {
				$ip = getenv('HTTP_CLIENT_IP');
			} else {
				$ip = getenv('REMOTE_ADDR');
			}
		}

		return $ip;
	}

	/**
	 * Get the complete payment return URL.
	 *
	 * @param int $storeId the ID of the store
	 * @return string
	 */
	public function getReturnUrl($storeId = null)
	{
		$params = [];
		$params['_secure'] = $this->_storeManager->getStore($storeId)->isCurrentlySecure();

		if($storeId) {
			$params['_store'] = $storeId;
		}

		return $this->_getUrl('payby/payment/response', $params);
	}
	public function getHomeUrl($storeId = null)
	{
		$params = [];
		$params['_secure'] = $this->_storeManager->getStore($storeId)->isCurrentlySecure();

		if($storeId) {
			$params['_store'] = $storeId;
		}

		return $this->_getUrl('', $params);
	}

	/**
	 * Return true if this is a backend session.
	 *
	 * @return bool
	 */
	public function isBackend()
	{
		return $this->_storeManager->getStore()->getCode() == \Magento\Store\Model\Store::ADMIN_CODE;
	}

	/**
	 * Return true if SSL is enabled for current store.
	 *
	 * @return bool
	 */
	public function isCurrentlySecure()
	{
		return $this->_storeManager->getStore()->isCurrentlySecure();
	}

	/**
	 * Return current checkout store.
	 *
	 * @return int
	 */
	public function getCheckoutStoreId()
	{
		$sessionClass = 'Magento\Checkout\Model\Session';
		if($this->isBackend()) {
			$sessionClass = 'Magento\Backend\Model\Session\Quote';
		}

		$session = $this->_objectManager->get($sessionClass);
		return $session->getStoreId();
	}

	/**
	 * Return current checkout quote.
	 *
	 * @return \Magento\Quote\Model\Quote
	 */
	public function getCheckoutQuote()
	{
		$sessionClass = 'Magento\Checkout\Model\Session';
		if($this->isBackend()) {
			$sessionClass = 'Magento\Backend\Model\Session\Quote';
		}

		$session = $this->_objectManager->get($sessionClass);
		return $session->getQuote();
	}

	/**
	 * Return true if Magento shop is in maintenance mode.
	 *
	 * @return bool
	 */
	public function isMaintenanceMode()
	{
		return $this->_maintenanceMode->isOn($this->getIpAddress());
	}

	/**
	 * Check if image file is uploaded to media directory.
	 *
	 * @return string
	 */
	public function isUploadFileImageExists($fileName)
	{
		$filePath = $this->_filesystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath('payby/images/' . $fileName);
		return file_exists($filePath);
	}

	/**
	 * Returns a configuration parameter from XML files.
	 *
	 * @param string $group
	 * @return string
	 */
	public function getGroupTitle($path)
	{
		// $path is as payment_[lang]/payby/payby_[group]/payby_[sub_group]
		$parts = explode('/', $path);
		$parentPath = 'payment/' . $parts[1] . '/' . $parts[2]; // we need the second level group

		return __($this->_configStructure->getElement($parentPath)->getLabel())->render();
	}

	/**
	 * Add a model config parameter for each of given $options (multi payment options).
	 *
	 * @param array[string][mixed] $options
	 */
	public function updateMultiPaymentModelConfig($options)
	{
		// retrieve DB connection
		$connection = $this->_resourceConfig->getConnection();

		// get config_data model table name & execute query
		$query = "DELETE FROM `{$this->_resourceConfig->getMainTable()}` WHERE `path` LIKE 'payment/payby\_multi\_%x/model'";
		$connection->query($query);

		foreach ($options as $option) {
			$this->_resourceConfig->saveConfig(
					'payment/payby_multi_' . $option['count'] . 'x/model',
					'PayBy\Payment\Model\Method\Multix',
					ScopeConfigInterface::SCOPE_TYPE_DEFAULT,
					0
			);
		}
	}

	/**
	 * Get multi payment method models.
	 *
	 * @return array[int] $options
	 */
	public function getMultiPaymentModelConfig()
	{
		// retrieve DB connection
		$connection = $this->_resourceConfig->getConnection();

		$select = $connection->select()
								->from($this->_resourceConfig->getMainTable())
								->where('path LIKE ?', 'payment/payby\_multi\_%x/model');

		return $connection->fetchAll($select);
	}

	/**
	 * Log function.
	 *
	 * @param $message
	 * @param $level
	 */
	public function log($message, $level=\Psr\Log\LogLevel::INFO)
	{
		$currentMethod = $this->_getCallerMethod();

		if (!$this->getCommonConfigData('enable_logs')) {
			return;
		}

		$log  = '';
		$log .= 'Payby 2.0.0';
		$log .= ' - ' . $currentMethod;
		$log .= ' : ' . $message;

		$this->_logger->log($level, $log);
	}

	/**
	 * Find the name of the method that called the log method.
	 * @return string|null
	 */
	private function _getCallerMethod()
	{
		$traces = debug_backtrace();

		if (isset($traces[2])) {
			return $traces[2]['function'];
		}

		return null;
	}
    public function isPaidUsingPayby(Order $order)
    {

        $payment = $order->getPayment();
        $method = $payment->getMethodInstance();
        $methodTitle = $method->getTitle();
        $additionalData = $order->getPayment()->getAdditionalInformation();


        if (isset($additionalData['checkout_type'])) {
            if ($additionalData['checkout_type'] != 'order') {
                return false;
            }
        }
        if ($method->getCode() == 'payby_standard') {
            return true;
        }
        return false;
    }
}