<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
 *
 * @category  payment
 * @package   payby  
 * @copyright PayBy.com
 * @version   2.0.0 
 */
namespace PayBy\Payment\Block\Payment;

class Redirect extends \Magento\Framework\View\Element\Template
{
	const PARAMS_REGISTRY_KEY = 'payby_form_params';
	const URL_REGISTRY_KEY = 'payby_form_url';

	/**
	 * @var \Magento\Framework\Registry
	 */
	protected $_coreRegistry;

	/**
	 * @param \Magento\Framework\View\Element\Template\Context $context
	 * @param \Magento\Framework\Registry $coreRegistry
	 * @param array $data
	 */
	public function __construct(
		\Magento\Framework\View\Element\Template\Context $context,
		\Magento\Framework\Registry $coreRegistry,
		array $data = []
	) {
		$this->_coreRegistry = $coreRegistry;
		parent::__construct($context, $data);
	}

	/**
	 * Get Form data by using ops payment api
	 *
	 * @return array
	 */
	public function getFormFields()
	{
		return $this->_coreRegistry->registry(self::PARAMS_REGISTRY_KEY);;
	}

	/**
	 * Getting platform url
	 *
	 * @return string
	 */
	public function getFormAction()
	{
		return $this->_coreRegistry->registry(self::URL_REGISTRY_KEY);;
	}
}