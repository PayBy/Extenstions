<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
 *
 * @category  payment
 * @package   payby  
 * @copyright PayBy.com
 * @version   2.0.0 
 */
namespace PayBy\Payment\Block\Payment;

use PayBy\Payment\Model\Api\PaybyResponse;

class Info extends \Magento\Payment\Block\Info
{
	/**
	 * @var string
	 */
	protected $_template = 'PayBy_Payment::payment/info.phtml';

	/**
	 * @var \Magento\Framework\Locale\ResolverInterface
	 */
	protected $_localeResolver;

	/**
	 * @var \Magento\Framework\ObjectManagerInterface
	 */
	protected $_objectManager;

	/**
	 * @param \Magento\Framework\View\Element\Template\Context $context
	 * @param \Magento\Framework\Locale\ResolverInterface $localeResolver
	 * @param \Magento\Framework\ObjectManagerInterface $objectManager
	 * @param array $data
	 */
	public function __construct(
			\Magento\Framework\View\Element\Template\Context $context,
			\Magento\Framework\Locale\ResolverInterface $localeResolver,
			\Magento\Framework\ObjectManagerInterface $objectManager,
			array $data = []
	) {
		$this->_localeResolver = $localeResolver;
		$this->_objectManager = $objectManager;
		parent::__construct($context, $data);
	}

	public function getResultDescription()
	{
		$allResults = @unserialize($this->getInfo()->getAdditionalInformation(\PayBy\Payment\Helper\Payment::ALL_RESULTS));

		if(!is_array($allResults) || !count($allResults)) {
			// description is stored as litteral string
			return $this->getInfo()->getCcStatusDescription();
		} else {
			// description is stored as serialized array
			$keys = ['result', 'auth_result', 'warranty_result'];

			$labels = [];
			foreach ($keys as $key) {
				$label = $this->translate($allResults[$key], $key);
				if(!$label) {
					continue;
				}

				$label = PaybyResponse::appendResultCode($label, $allResults[$key]);

				if ($key === 'result' && $allResults[$key] == '30') {
					$extraResult = $allResults['extra_result'];
					$label .= ' ' . PaybyResponse::appendResultCode(PaybyResponse::$FORM_ERRORS[$extraResult], $extraResult);
				}

				$labels[] = $label;
			}

			return implode('<br />', $labels);
		}
	}

	public function getPaymentDetailsHtml()
	{
		$html = '';
		$payment = $this->getInfo();

		$html .= __('Payment Mean') . ' : ' . $payment->getCcType();
		$html .= '<br />';

		$html .= __('Credit Card Number') . ' : ' . $payment->getCcNumberEnc();
		$html .= '<br />';

		$expiry = '';
		if($payment->getCcExpMonth() && $payment->getCcExpYear()) {
			$expiry = str_pad($payment->getCcExpMonth(), 2, '0', STR_PAD_LEFT) . ' / ' . $payment->getCcExpYear();
		}
		$html .= __('Expiration Date') . ' : ' . $expiry;
		$html .= '<br />';

		$html .= __('3-DS Authentication') . ' : ';
		if($payment->getCcSecureVerify()) {
			$html .=  __('YES');
			$html .= '<br />';
			$html .= __('3-DS Certificate') . ' : ' . $payment->getCcSecureVerify();
		} else {
			$html .= __('NO');
		}

		return $html;
	}

	public function getTransactionsDetailsHtml()
	{
		$collection = $this->_objectManager->create('Magento\Sales\Model\ResourceModel\Order\Payment\Transaction\Collection');
		$collection->addPaymentIdFilter($this->getInfo());
		$collection->load();

		$html = '';

		foreach ($collection as $item) {
			$html .= '<hr />';

			$html .= __('Sequence Number') . ' : ' . substr($item->getTxnId(), strpos($item->getTxnId(), '-') + 1);
			$html .= '<br />';

			$info = $item->getAdditionalInformation(\Magento\Sales\Model\Order\Payment\Transaction::RAW_DETAILS);
			foreach ($info as $key => $value) {
				$html .= __($key) . ' : ' . $value;
				$html .= '<br />';
			}
		}

		return $html;
	}

	public function translate($text, $type)
	{
		$lang = strtolower(substr($this->_localeResolver->getLocale(), 0, 2));

		return PaybyResponse::translate($text, $type, $lang);
	}
}