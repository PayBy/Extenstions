<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
 *
 * @category  payment
 * @package   payby  
 * @copyright PayBy.com
 * @version   2.0.0 
 */
namespace PayBy\Payment\Block\Adminhtml\System\Config\Form\Field\Renderer;

use Magento\Framework\UrlInterface;

class ColumnUploadButton extends \Magento\Framework\View\Element\AbstractBlock
{
	/**
	 * @var \Magento\Framework\UrlInterface
	 */
	protected $_url;

	/**
	 * @param \Magento\Framework\View\Element\Context $context
	 * @param array $data
	 */
	public function __construct(
			\Magento\Framework\View\Element\Context $context,
			array $data = []
	) {
		$this->_url = $context->getUrlBuilder();

		parent::__construct($context, $data);
	}

	protected function _toHtml()
	{
		$column = $this->getColumn();

		$html = '<div' . ($column['style'] ? ' style="' . $column['style'] . '"' : '') . '>';

		$html .= '<input type="file" name="'. $this->getInputName() . '" value="<%- ' . $this->getColumnName() . ' %>"';
		$html .= ' class="' . ($column['class'] ? $column['class'] : 'input-text') . '"';
		if($column['size']) {
			$html .= ' size="' . $column['size'] . '"';
		}
		$html .= '/>';

		$src = $this->_url->getBaseUrl(UrlInterface::URL_TYPE_MEDIA) . 'payby/gift/<%- logo %>?' . time();
		$html .= '<img style="margin-left: 10px; vertical-align: middle; height: 18px;" alt="<%- code %>" src="' . $src . '" title="<%- name %>}" >';

		$html .= '</div>';

		return $html;
	}
}