<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
 *
 * @category  payment
 * @package   payby  
 * @copyright PayBy.com
 * @version   2.0.0 
 */
namespace PayBy\Payment\Block\Adminhtml\System\Config\Form\Field;

/**
 * Custom renderer for the Payby category mapping field.
 */
class CategoryMapping extends \PayBy\Payment\Block\Adminhtml\System\Config\Form\Field\FieldArray\ConfigFieldArray
{
	/**
	 * @var \Magento\Store\Model\StoreManagerInterface
	 */
	protected $_storeManager;

	/**
	 * @var \PayBy\Payment\Model\System\Config\Source\CategoryFactory
	 */
	protected $_paybyCategoryFactory;

	/**
	 * @var \Magento\Catalog\Model\CategoryFactory
	 */
	protected $_categoryFactory;

	/**
	 * @var bool
	 */
	protected $_static = true;

	/**
	 * @param \Magento\Backend\Block\Template\Context $context
	 * @param \PayBy\Payment\Model\System\Config\Source\CategoryFactory $paybyCategoryFactory
	 * @param \Magento\Catalog\Model\CategoryFactory $categoryFactory
	 * @param array $data
	 */
	public function __construct(
			\Magento\Backend\Block\Template\Context $context,
			\PayBy\Payment\Model\System\Config\Source\CategoryFactory $paybyCategoryFactory,
			\Magento\Catalog\Model\CategoryFactory $categoryFactory,
			array $data = []
	) {
		$this->_storeManager = $context->getStoreManager();
		$this->_paybyCategoryFactory = $paybyCategoryFactory;
		$this->_categoryFactory = $categoryFactory;

		parent::__construct($context, $data);
	}

	/**
	 * Prepare to render.
	 *
	 * @return void
	 */
	public function _prepareToRender()
	{
		$this->addColumn('magento_category', [
				'label' => __('Magento category'),
				'style' => 'width: 200px;',
				'renderer' => $this->_getLabelRenderer('_magentoCategory')
		]);

		$options = [];
		foreach ($this->_paybyCategoryFactory->create()->toOptionArray(true) as $option) {
			$options[$option['value']] = $option['label'];
		}

		$this->addColumn('payby_category', [
				'label' => __('Payby category'),
				'style' => 'width: 200px;',
				'renderer' => $this->_getListRenderer('_paybyCategory', $options)
		]);

		parent::_prepareToRender();
	}

	/**
	 * Obtain existing data from form element.
	 * Each row will be instance of \Magento\Framework\DataObject
	 *
	 * @return array
	 */
	public function getArrayRows()
	{
		$value = array();

		/* var $allCategories Array[string][string] code => name */
		$allCategories = $this->_getAllCategories();

		$savedCategories = $this->getElement()->getValue();
		if($savedCategories && is_array($savedCategories) && count($savedCategories) > 0) {
			foreach ($savedCategories as $id => $category) {
				if(key_exists($category['code'], $allCategories)) {
					// update magento category name
					$category['magento_category'] = $allCategories[$category['code']];
					$value[$id] = $category;

					unset ($allCategories[$category['code']]);
				}
			}
		}

		// add not saved yet categories
		if($allCategories && is_array($allCategories) && count($allCategories) > 0) {
			foreach ($allCategories as $code => $name) {
				$value[uniqid('_' . $code . '_')] = array(
						'code' => $code,
						'magento_category' => $name,
						'payby_category' => 'FOOD_AND_GROCERY',
						'mark' => true
				);
			}
		}

		$this->getElement()->setValue($value);
		return parent::getArrayRows();
	}

	private function _getAllCategories()
	{
		$categories = $this->_categoryFactory->create()->getCollection()
					->addAttributeToSelect('name')
					->addAttributeToSelect('id')
					->addIsActiveFilter();

		if($this->getElement()->getScope() === \Magento\Config\Block\System\Config\Form::SCOPE_STORES) {
			$rootId = $this->_storeManager->getStore($this->getElement()->getScopeId())->getRootCategoryId();

			$categories = $categories->addFieldToFilter(array(
					array('attribute' => 'path', 'like' => "1/$rootId/%"),
					array('attribute' => 'path', 'eq' => "1/$rootId")
			));
		}

		$allCategories = array();
		foreach ($categories as $category) {
			$allCategories[$category->getId()] = $category->getName();
		}

		return $allCategories;
	}

	protected function _getDependsOnField() {
		$thisEltId = $this->getElement()->getId();
		return str_replace('category_mapping', 'common_category', $thisEltId);
	}

	protected function _getDependsOnValue() {
		return 'CUSTOM_MAPPING';
	}
}