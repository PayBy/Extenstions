<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
 *
 * @category  payment
 * @package   payby  
 * @copyright PayBy.com
 * @version   2.0.0 
 */
namespace PayBy\Payment\Block\Adminhtml\System\Config\Form\Field\Renderer;

class ColumnLabel extends \Magento\Framework\View\Element\AbstractBlock
{
	/**
	 * @param \Magento\Framework\View\Element\Context $context
	 * @param array $data
	 */
	public function __construct(
			\Magento\Framework\View\Element\Context $context,
			array $data = []
	) {
		parent::__construct($context, $data);
	}

	protected function _toHtml()
	{
		$column = $this->getColumn();

		$codeInputName = str_replace($this->getColumnName(), 'code', $this->getInputName());
		$html = '<input type="hidden" value="<%- code %>" name="' . $codeInputName . '">';

		$html .= '<div';
		$html .= ' class="' . ($column['class'] ? $column['class'] : 'input-text') . '"';
		$html .= $column['style'] ? ' style="' . $column['style'] . '"' : '';
		$html .= '>';


		$html .= '<%- ' . $this->getColumnName() . ' %><% if (typeof mark != "undefined" && mark) { %><span style="color: red;">*</span><% } %>';
		$html .= '</div>';

		return $html;
	}
}