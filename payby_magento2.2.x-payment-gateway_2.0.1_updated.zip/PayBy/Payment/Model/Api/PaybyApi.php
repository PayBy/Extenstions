<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
 *
 * @category  payment
 * @package   payby  
 * @copyright PayBy.com
 * @version   2.0.0 
 */
namespace PayBy\Payment\Model\Api;

if (! class_exists('PaybyApi', false)) {

	/**
	 * Utility class for managing parameters checking, inetrnationalization, signature building and more.
	 */
	class PaybyApi
	{

		/**
		 * The list of encodings supported by the API.
		 *
		 * @var array[string]
		 */
		public static $SUPPORTED_ENCODINGS = array(
				'UTF-8',
				'ASCII',
				'Windows-1252',
				'ISO-8859-15',
				'ISO-8859-1',
				'ISO-8859-6',
				'CP1256'
		);

		/**
		 * Generate a trans_id.
		 * To be independent from shared/persistent counters, we use the number of 1/10 seconds since midnight
		 * which has the appropriatee format (000000-899999) and has great chances to be unique.
		 *
		 * @param int $timestamp
		 * @return string the generated trans_id
		 */
		public static function generateTransId($timestamp = null)
		{
			if (! $timestamp) {
				$timestamp = time();
			}

			$parts = explode(' ', microtime());
			$id = ($timestamp + $parts[0] - strtotime('today 00:00')) * 10;
			$id = sprintf('%06d', $id);

			return $id;
		}

		/**
		 * Returns an array of languages accepted by the Payby payment platform.
		 *
		 * @return array[string][string]
		 */
		public static function getSupportedLanguages()
		{
			return array(
				'de' => 'German', 'en' => 'English', 'zh' => 'Chinese', 'es' => 'Spanish', 'fr' => 'French',
				'it' => 'Italian', 'ja' => 'Japanese', 'nl' => 'Dutch', 'pl' => 'Polish', 'pt' => 'Portuguese',
				'ru' => 'Russian', 'sv' => 'Swedish', 'tr' => 'Turkish'
			);
		}

		/**
		 * Returns true if the entered language (ISO code) is supported.
		 *
		 * @param string $lang
		 * @return boolean
		 */
		public static function isSupportedLanguage($lang)
		{
			foreach (array_keys(self::getSupportedLanguages()) as $code) {
				if ($code == strtolower($lang)) {
					return true;
				}
			}

			return false;
		}

		/**
		 * Return the list of currencies recognized by the Payby platform.
		 *
		 * @return array[int][PaybyCurrency]
		 */
		public static function getSupportedCurrencies()
		{
			$currencies = array(
				array('AED', '032', 2)
			);

			$payby_currencies = array();

			foreach ($currencies as $currency) {
				$payby_currencies[] = new PaybyCurrency($currency[0], $currency[1], $currency[2]);
			}

			return $payby_currencies;
		}

		/**
		 * Return a currency from its 3-letters ISO code.
		 *
		 * @param string $alpha3
		 * @return PaybyCurrency
		 */
		public static function findCurrencyByAlphaCode($alpha3)
		{
			$list = self::getSupportedCurrencies();
			foreach ($list as $currency) {
				/**
				 * @var PaybyCurrency $currency
				 */
				if ($currency->getAlpha3() == $alpha3) {
					return $currency;
				}
			}

			return null;
		}

		/**
		 * Returns a currency form its numeric ISO code.
		 *
		 * @param int $numeric
		 * @return PaybyCurrency
		 */
		public static function findCurrencyByNumCode($numeric)
		{
			$list = self::getSupportedCurrencies();
			foreach ($list as $currency) {
				/**
				 * @var PaybyCurrency $currency
				 */
				if ($currency->getNum() == $numeric) {
					return $currency;
				}
			}

			return null;
		}

		/**
		 * Returns currency numeric ISO code from its 3-letters code.
		 *
		 * @param string $alpha3
		 * @return int
		 */
		public static function getCurrencyNumCode($alpha3)
		{
			$currency = self::findCurrencyByAlphaCode($alpha3);
			return ($currency instanceof PaybyCurrency) ? $currency->getNum() : null;
		}

		/**
		 * Returns an array of card types accepted by the Payby payment platform.
		 *
		 * @return array[string][string]
		 */
		public static function getSupportedCardTypes()
		{
			return array(
				'CB' => 'CB', 'E-CARTEBLEUE' => 'E-Carte bleue', 'MAESTRO' => 'Maestro', 'MASTERCARD' => 'MasterCard',
				'VISA' => 'Visa', 'VISA_ELECTRON' => 'Visa Electron', 'AMEX' => 'American Express',
				'ACCORD_STORE' => 'Carte de paiement Banque Accord', 'ACCORD_STORE_SB' => 'Carte de paiement Banque Accord - Sandbox',
				'ALINEA' => 'Carte Privative Alinea', 'ALINEA_CDX' => 'Carte cadeau Alinea',
				'ALINEA_CDX_SB' => 'Carte cadeau Alinea - SandBox', 'ALINEA_SB' => 'Carte Privative Alinea - SandBox',
				'AURORE-MULTI' => 'Carte Aurore', 'BANCONTACT' => 'Carte Maestro Bancontact Mistercash',
				'BITCOIN' => 'Paiement par monnaie virtuelle', 'BIZZBEE_CDX' => 'Carte cadeau Bizzbee',
				'BIZZBEE_CDX_SB' => 'Carte cadeau Bizzbee - Sandbox', 'BRICE_CDX' => 'Carte cadeau Brice',
				'BRICE_CDX_SB' => 'Carte cadeau Brice - Sandbox', 'CDGP' => 'Carte Privilège', 'COF3XCB' => '3 fois CB Cofinoga',
				'COF3XCB_SB' => '3 fois CB Cofinoga - Sandbox', 'COFINOGA' => 'Carte Be Smart', 'CORA_BLANCHE' => 'Carte Cora Blanche',
				'CORA_PREM' => 'Carte Cora Premium', 'CORA_VISA' => 'Carte Cora Visa', 'DINERS' => 'Carte Diners Club',
				'E_CV' => 'E-chèque vacance', 'EDENRED' => 'Carte "Ticket Restaurant"', 'GIROPAY' => 'Virement bancaire',
				'KLARNA' => 'Paiement par facture', 'IDEAL' => 'iDEAL virement bancaire', 'ILLICADO' => 'Carte cadeau Illicado',
				'ILLICADO_SB' => 'Carte cadeau Illicado - Sandbox', 'JCB' => 'Carte JCB', 'JOUECLUB_CDX' => 'Carte cadeau Jouéclub',
				'JOUECLUB_CDX_SB' => 'Carte cadeau Jouéclub - Sandbox', 'JULES_CDX' => 'Carte cadeau Jules',
				'JULES_CDX_SB' => 'Carte cadeau Jules - Sandbox', 'ONEY' => 'Paiement en 3/4 fois Oney FacilyPay',
				'ONEY_SANDBOX' => 'Paiement en 3/4 fois Oney FacilyPay - Sandbox', 'PAYLIB' => 'Paylib', 'PAYPAL' => 'PayPal',
				'PAYPAL_SB' => 'PayPal - Sandbox', 'PAYSAFECARD' => 'Carte prépayée Paysafecard', 'POSTFINANCE' => 'PostFinance',
				'POSTFINANCE_EFIN' => 'PostFinance mode E-finance', 'RUPAY' => 'RuPay', 'S-MONEY' => 'S-Money',
				'SCT' => 'Virement SEPA', 'SDD' => 'Prélèvement SEPA', 'SOFORT_BANKING' => 'Sofort',
				'TRUFFAUT_CDX' => 'Carte cadeau Truffaut'
			);
		}

		/**
		 * Compute a Payby signature. Parameters must be in UTF-8.
		 *
		 * @param array[string][string] $parameters payment platform request/response parameters
		 * @param string $key shop certificate
		 * @param boolean $hashed set to false to get the unhashed signature
		 * @return string
		 */
		public static function sign($parameters, $key, $hashed = true)
		{
			ksort($parameters);

			$sign = '';
			foreach ($parameters as $name => $value) {
				if (substr($name, 0, 5) == 'vads_') {
					$sign .= $value . '+';
				}
			}

			$sign .= $key;
			return $hashed ? sha1($sign) : $sign;
		}

		/**
		 * PHP is not yet a sufficiently advanced technology to be indistinguishable from magic...
		 * so don't use magic_quotes, they mess up with the platform response analysis.
		 *
		 * @param array $potentially_quoted_data
		 * @return mixed
		 */
		public static function uncharm($potentially_quoted_data)
		{
			if (get_magic_quotes_gpc()) {
				$sane = array();
				foreach ($potentially_quoted_data as $k => $v) {
					$sane_key = stripslashes($k);
					$sane_value = is_array($v) ? self::uncharm($v) : stripslashes($v);
					$sane[$sane_key] = $sane_value;
				}
			} else {
				$sane = $potentially_quoted_data;
			}

			return $sane;
		}
	}
}