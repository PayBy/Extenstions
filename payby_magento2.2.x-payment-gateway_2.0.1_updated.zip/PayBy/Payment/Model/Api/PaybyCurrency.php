<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
 *
 * @category  payment
 * @package   payby  
 * @copyright PayBy.com
 * @version   2.0.0 
 */
namespace PayBy\Payment\Model\Api;

if (! class_exists('PaybyCurrency', false)) {

	/**
	 * Class representing a currency, used for converting alpha/numeric ISO codes and float/integer amounts.
	 */
	class PaybyCurrency
	{

		private $alpha3;
		private $num;
		private $decimals;

		public function __construct($alpha3, $num, $decimals = 2)
		{
			$this->alpha3 = $alpha3;
			$this->num = $num;
			$this->decimals = $decimals;
		}

		public function convertAmountToInteger($float)
		{
			$coef = pow(10, $this->decimals);

			$amount = $float * $coef;
			return (int) (string) $amount; // cast amount to string (to avoid rounding) than return it as int
		}

		public function convertAmountToFloat($integer)
		{
			$coef = pow(10, $this->decimals);

			return ((float) $integer) / $coef;
		}

		public function getAlpha3()
		{
			return $this->alpha3;
		}

		public function getNum()
		{
			return $this->num;
		}

		public function getDecimals()
		{
			return $this->decimals;
		}
	}
}