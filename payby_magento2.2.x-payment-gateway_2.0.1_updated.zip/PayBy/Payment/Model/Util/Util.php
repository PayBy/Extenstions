<?php

namespace PayBy\Payment\Model\Util;

use PayBy\Payment\Model\PayByObject;
use stdClass;

abstract class Util
{
    /**
     * Whether the provided array (or other) is a list rather than a dictionary.
     *
     * @param array|mixed $array
     * @return boolean True if the given object is a list.
     */
    public static function isList($array)
    {
        if (!is_array($array)) {
            return false;
        }

        // TODO: generally incorrect, but it's correct given PayBy's response
        foreach (array_keys($array) as $k) {
            if (!is_numeric($k)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Recursively converts the PHP PayBy object to an array.
     *
     * @param array $values The PHP PayBy object to convert.
     * @param bool
     * @return array
     */
    public static function convertPayByObjectToArray($values, $keep_object = false)
    {
        $results = [];
        foreach ($values as $k => $v) {
            // FIXME: this is an encapsulation violation
            if ($k[0] == '_') {
                continue;
            }
            if ($v instanceof PayByObject) {
                $results[$k] = $keep_object ? $v->__toStdObject(true) : $v->__toArray(true);
            } elseif (is_array($v)) {
                $results[$k] = self::convertPayByObjectToArray($v, $keep_object);
            } else {
                $results[$k] = $v;
            }
        }
        return $results;
    }

    /**
     * Recursively converts the PHP PayBy object to an stdObject.
     *
     * @param array $values The PHP PayBy object to convert.
     * @return array
     */
    public static function convertPayByObjectToStdObject($values)
    {
        $results = new stdClass;
        foreach ($values as $k => $v) {
            // FIXME: this is an encapsulation violation
            if ($k[0] == '_') {
                continue;
            }
            if ($v instanceof PayByObject) {
                $results->$k = $v->__toStdObject(true);
            } elseif (is_array($v)) {
                $results->$k = self::convertPayByObjectToArray($v, true);
            } else {
                $results->$k = $v;
            }
        }
        return $results;
    }

    /**
     * Converts a response from the PayBy API to the corresponding PHP object.
     *
     * @param stdObject $resp The response from the PayBy API.
     * @return PayByObject|array
     */
    public static function convertToPayByObject($resp)
    {
        $types = [
            'agreement' => \PayBy\Payment\Model\Agreement::class,
            'balance_bonus' => \PayBy\Payment\Model\BalanceBonus::class,
            'balance_settlement' => \PayBy\Payment\Model\BalanceSettlements::class,
            'balance_transaction' => \PayBy\Payment\Model\BalanceTransaction::class,
            'balance_transfer' => \PayBy\Payment\Model\BalanceTransfer::class,
            'batch_refund' => \PayBy\Payment\Model\BatchRefund::class,
            'batch_transfer' => \PayBy\Payment\Model\BatchTransfer::class,
            'batch_withdrawal' => \PayBy\Payment\Model\BatchWithdrawal::class,
            'channel' => \PayBy\Payment\Model\Channel::class,
            'charge' => \PayBy\Payment\Model\Charge::class,
            'coupon' => \PayBy\Payment\Model\Coupon::class,
            'coupon_template' => \PayBy\Payment\Model\CouponTemplate::class,
            'customs' => \PayBy\Payment\Model\Customs::class,
            'event' => \PayBy\Payment\Model\Event::class,
            'list' => \PayBy\Payment\Model\Collection::class,
            'order' => \PayBy\Payment\Model\Order::class,
            'profit_transaction' => \PayBy\Payment\Model\ProfitTransaction::class,
            'recharge' => \PayBy\Payment\Model\Recharge::class,
            'red_envelope' => \PayBy\Payment\Model\RedEnvelope::class,
            'refund' => \PayBy\Payment\Model\Refund::class,
            'royalty' => \PayBy\Payment\Model\Royalty::class,
            'royalty_settlement' => \PayBy\Payment\Model\RoyaltySettlement::class,
            'royalty_template' => \PayBy\Payment\Model\RoyaltyTemplate::class,
            'royalty_transaction' => \PayBy\Payment\Model\RoyaltyTransaction::class,
            'settle_account' => \PayBy\Payment\Model\SettleAccount::class,
            'split_profit' => \PayBy\Payment\Model\SplitProfit::class,
            'split_receiver' => \PayBy\Payment\Model\SplitReceiver::class,
            'sub_app' => \PayBy\Payment\Model\SubApp::class,
            'sub_bank' => \PayBy\Payment\Model\SubBank::class,
            'transfer' => \PayBy\Payment\Model\Transfer::class,
            'user' => \PayBy\Payment\Model\User::class,
            'withdrawal' => \PayBy\Payment\Model\Withdrawal::class,
        ];
        if (self::isList($resp)) {
            $mapped = [];
            foreach ($resp as $i) {
                array_push($mapped, self::convertToPayByObject($i));
            }
            return $mapped;
        } elseif (is_object($resp)) {
            if (isset($resp->object)
                && is_string($resp->object)
                && isset($types[$resp->object])) {
                    $class = $types[$resp->object];
            } else {
                $class = 'Payby\\Payment\\Model\\PayByObject';
            }
            return $class::constructFrom($resp);
        } else {
            return $resp;
        }
    }

    /**
     * Get the request headers
     * @return array An hash map of request headers.
     */
    public static function getRequestHeaders()
    {
        if (function_exists('getallheaders')) {
            $headers = [];
            foreach (getallheaders() as $name => $value) {
                $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('-', ' ', $name))))] = $value;
            }
            return $headers;
        }
        $headers = [];
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) == 'HTTP_') {
                $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
            }
        }
        return $headers;
    }

    /**
     * @param string|mixed $value A string to UTF8-encode.
     *
     * @return string|mixed The UTF8-encoded string, or the object passed in if
     *    it wasn't a string.
     */
    public static function utf8($value)
    {
        if (is_string($value)
            && mb_detect_encoding($value, "UTF-8", true) != "UTF-8"
        ) {
            return utf8_encode($value);
        } else {
            return $value;
        }
    }
}
