<?php

namespace PayBy\Payment\Model\Error;
class ApiConnection extends Base
{
}
