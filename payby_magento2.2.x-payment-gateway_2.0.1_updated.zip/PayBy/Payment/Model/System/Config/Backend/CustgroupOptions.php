<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
  
 * @category  payment
 * @package   payby

 * @copyright  2020
 * @license      Commercial License 
 * @version   2.0.0 
 */
namespace PayBy\Payment\Model\System\Config\Backend;

class CustgroupOptions extends \PayBy\Payment\Model\System\Config\Backend\Serialized\ArraySerialized\ConfigArraySerialized
{
	public function beforeSave()
	{
		$values = $this->getValue();

		if(!is_array($values) || empty($values)) {
			$this->setValue(array());
		} else {
			$i = 0;
			foreach ($values as $key => $value) {
				$i++;

				if(empty($value)) {
					continue;
				}

				if(!empty($value['amount_min']) && (!is_numeric($value['amount_min']) || $value['amount_min'] < 0)) {
					$this->_throwException('Minimum amount', $i);
				} elseif(!empty($value['amount_max']) && (!is_numeric($value['amount_max']) || $value['amount_max'] < 0)) {
					$this->_throwException('Maximum amount', $i);
				}
			}
		}

		return parent::beforeSave();
	}
}