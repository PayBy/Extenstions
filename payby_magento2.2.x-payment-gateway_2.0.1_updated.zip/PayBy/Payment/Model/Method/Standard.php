<?php
/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
 *
 * @category  payment
 * @package   payby  
 * @copyright PayBy.com
 * @version   2.0.0 
 */
namespace PayBy\Payment\Model\Method;

class Standard extends Payby
{
	protected $_code = \PayBy\Payment\Helper\Data::METHOD_STANDARD;
	protected $_formBlockType = 'PayBy\Payment\Block\Payment\Form\Standard';

	protected $_canSaveCc = true;

	/**
	 * @var \Magento\Customer\Api\CustomerRepositoryInterface
	 */
	protected $_customerRepository;

	/**
	 * @param \Magento\Framework\Model\Context $context
	 * @param \Magento\Framework\Registry $registry
	 * @param \Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory
	 * @param \Magento\Framework\Api\AttributeValueFactory $customAttributeFactory
	 * @param \Magento\Payment\Helper\Data $paymentData
	 * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
	 * @param \Magento\Payment\Model\Method\Logger $logger
	 * @param \Magento\Framework\ObjectManagerInterface $objectManager
	 * @param \Magento\Framework\Locale\ResolverInterface $localeResolver
	 * @param \Magento\Framework\UrlInterface $urlBuilder
	 * @param \PayBy\Payment\Model\Api\PaybyRequest $paybyRequest
	 * @param \PayBy\Payment\Helper\Data $dataHelper
	 * @param \PayBy\Payment\Helper\Payment $paymentHelper
	 * @param \PayBy\Payment\Helper\Checkout $checkoutHelper
	 * @param \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository
	 * @param \Magento\Framework\Model\ResourceModel\AbstractResource $resource
	 * @param \Magento\Framework\Data\Collection\AbstractDb $resourceCollection
	 * @param array $data
	 */
	public function __construct(
			\Magento\Framework\Model\Context $context,
			\Magento\Framework\Registry $registry,
			\Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory,
			\Magento\Framework\Api\AttributeValueFactory $customAttributeFactory,
			\Magento\Payment\Helper\Data $paymentData,
			\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
			\Magento\Payment\Model\Method\Logger $logger,
			\Magento\Framework\ObjectManagerInterface $objectManager,
			\Magento\Framework\Locale\ResolverInterface $localeResolver,
			\Magento\Framework\UrlInterface $urlBuilder,
			\PayBy\Payment\Model\Api\PaybyRequestFactory $paybyRequestFactory,
			\PayBy\Payment\Helper\Data $dataHelper,
			\PayBy\Payment\Helper\Payment $paymentHelper,
			\PayBy\Payment\Helper\Checkout $checkoutHelper,
			\Magento\Customer\Api\CustomerRepositoryInterface $customerRepository,
			\Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
			\Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
			array $data = []
	) {
		$this->_customerRepository = $customerRepository;

		parent::__construct($context, $registry, $extensionFactory, $customAttributeFactory, $paymentData,
				$scopeConfig, $logger, $objectManager, $localeResolver, $urlBuilder, $paybyRequestFactory,
				$dataHelper, $paymentHelper, $checkoutHelper, $resource, $resourceCollection, $data);
	}


	protected function _setExtraFields($order)
	{
		$info = $this->getInfoInstance();

		if($this->getConfigData('oneclick_active') && $order->getCustomerId()) { // 1-Click enabled and customer logged-in
			$customer = $this->customerRepository->getById($this->getCustomerId());

			if($customer->getPaybyIdentifier() && $info->getAdditionalInformation(\PayBy\Payment\Helper\Payment::IDENTIFIER)) {
				// customer has an identifier and wants to use it
				$this->_dataHelper->log('Customer ' . $customer->getEmail() . ' has an identifier and chose to use it for payment.');
				$this->_paybyRequest->set('identifier', $customer->getPaybyIdentifier());
			} else {
				if($this->isLocalCcInfo() && $info->getAdditionalInformation(\PayBy\Payment\Helper\Payment::CC_REGISTER)) {
					// customer wants to register card data

					if ($customer->getPaybyIdentifier()) {
						// customer has already an identifier
						$this->_dataHelper->log('Customer ' . $customer->getEmail() . ' has an identifier and chose to update it with new card info.');
						$this->_paybyRequest->set('identifier', $customer->getPaybyIdentifier());
						$this->_paybyRequest->set('page_action', 'REGISTER_UPDATE_PAY');
					} else {
						$this->_dataHelper->log('Customer ' . $customer->getEmail() . ' has not identifier and chose to register his card info.');
						$this->_paybyRequest->set('page_action', 'REGISTER_PAY');
					}
				} elseif(!$this->isLocalCcInfo()) {
					// card data entry on payment page, let's ask customer for data registration
					$this->_dataHelper->log('Customer ' . $customer->getEmail() . ' will be asked for card data registration on payment page.');
					$this->_paybyRequest->set('page_action', 'ASK_REGISTER_PAY');
				}

				$this->_setCcInfo();
			}
		} else {
			$this->_setCcInfo();
		}
	}

	private function _setCcInfo()
	{
		$info = $this->getInfoInstance();

		if($this->isLocalCcType() || $this->isLocalCcInfo()) {
			// override payment_cards
			$this->_paybyRequest->set('payment_cards', $info->getCcType());
		}

		if($this->isLocalCcInfo()) {
			$this->_paybyRequest->set('cvv', $info->getCcCid());
			$this->_paybyRequest->set('card_number', $info->getCcNumber());
			$this->_paybyRequest->set('expiry_year', $info->getCcExpYear());
			$this->_paybyRequest->set('expiry_month', $info->getCcExpMonth());

			// override action_mode
			$this->_paybyRequest->set('action_mode', 'SILENT');
		}
	}

 
	/**
	 * Return true if redirection will be done in silent mode.
	 *
	 * @return bool
	 */
	public function isSilentMode()
	{
		return $this->isLocalCcInfo();
	}

	/**
	 * Return available card types.
	 *
	 * @return array[string][array]
	 */
	public function getAvailableCcTypes()
	{
		// all cards
		$allCards = $this->_dataHelper->getSupportedCcTypes();

		// selected cards from module configuration
		$cards = $this->_dataHelper->getCommonConfigData('payment_cards');

		if (!empty($cards)) {
			$cards = explode(',', $cards);
		} else {
			$cards = array_keys($allCards);
		}

		if (!$this->_sendOneyFields()) {
			$cards = array_diff($cards, array('ONEY', 'ONEY_SANDBOX'));
		}
		if(!$this->_sendPaypalFields()) {
			$cards = array_diff($cards, array('PAYPAL', 'PAYPAL_SB'));
		}

		$availCards = array();
		foreach ($allCards as $code => $label) {
			if (in_array($code, $cards)) {
				$availCards[$code] = $label;
			}
		}
		return $availCards;
	}

	public function isOneclickAvailable()
	{
		// no 1-Click
		if(!$this->getConfigData('oneclick_active')) {
			return false;
		}

		$session = $this->_objectManager->get('Magento\Customer\Model\Session');

		// customer not logged in
		if(!$session->isLoggedIn()) {
			return false;
		}

		// customer has not Payby identifier
		$customer = $session->getCustomer();
		if(!$customer || !$customer->getPaybyIdentifier()) {
			return false;
		}

		return true;
	}

	/**
	 * Assign data to info model instance.
	 *
	 * @param array|\Magento\Framework\DataObject $data
	 * @return $this
	 */
	public function assignData(\Magento\Framework\DataObject $data)
	{
		// reset payment method specific data
		$this->resetData();

		parent::assignData($data);

		$info = $this->getInfoInstance();

		if($data->getPaybyStandardUseIdentifier()) {
			$info->setAdditionalInformation(\PayBy\Payment\Helper\Payment::IDENTIFIER, true); // payment by identifier
		} else {
			// set card info
			$info->setCcType($data->getPaybyStandardCcType())
					->setCcLast4(substr($data->getPaybyStandardCcNumber(), -4))
					->setCcNumber($data->getPaybyStandardCcNumber())
					->setCcCid($data->getPaybyStandardCcCvv())
					->setCcExpMonth($data->getPaybyStandardCcExpMonth())
					->setCcExpYear($data->getPaybyStandardCcExpYear())
					->setAdditionalInformation(\PayBy\Payment\Helper\Payment::CC_REGISTER, $data->getPaybyStandardCcRegister()) // wether to register data
					->setAdditionalInformation(\PayBy\Payment\Helper\Payment::IDENTIFIER, false);
		}

		return $this;
	}

	/**
	 * Check if the card data entry on merchant site option is selected.
	 *
	 * @return bool
	 */
	public function isLocalCcInfo()
	{
		return $this->_dataHelper->isCurrentlySecure() // this is a double check, it's also done on backend side
				&& $this->getConfigData('card_info_mode') == 3;
	}

	/**
	 * Check if the local card type selection option is choosen.
	 * @return bool
	 */
	public function isLocalCcType()
	{
		return $this->getConfigData('card_info_mode') == 2;
	}
}