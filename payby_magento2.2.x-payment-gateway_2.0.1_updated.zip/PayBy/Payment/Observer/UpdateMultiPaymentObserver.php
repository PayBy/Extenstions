<?php
/**
  * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
  
 * @category  payment
 * @package   payby

 * @copyright  2020
 * @license      Commercial License 
 * @version   2.0.0 
 */
namespace PayBy\Payment\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;

class UpdateMultiPaymentObserver implements ObserverInterface
{
	/**
	 * Update payment method ID to set installments number if multi payment.
	 *
	 * @param Observer $observer
	 * @return void
	 */
	public function execute(Observer $observer)
	{
		$payment = $observer->getDataObject();

		if($payment->getMethod() != 'payby_multi') {
			// not payby multiple payment, do nothing
			return;
		}

		// retreive selected option
		$option = $payment->getAdditionalInformation(\PayBy\Payment\Helper\Payment::MULTI_OPTION);
		if(isset($option) && is_array($option)) {
			$payment->setMethod('payby_multi_' . $option['count'] . 'x');
		}
	}
}