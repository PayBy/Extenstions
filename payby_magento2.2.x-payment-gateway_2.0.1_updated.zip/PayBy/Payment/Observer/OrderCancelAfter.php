<?php

/**
 * PayBy V2-Payment Module version 2.0.0 for Magento 2.x.  
  
 * @category  payment
 * @package   payby

 * @copyright  2020
 * @license      Commercial License 
 * @version   2.0.0 
 */

namespace PayBy\Payment\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use Magento\Sales\Model\Order;
use Magento\Framework\Message\ManagerInterface;
use Magento\Framework\Exception\LocalizedException;

class OrderCancelAfter implements ObserverInterface
{
    private $messageManager;
    private $_dataHelper;
    public function __construct(
        ManagerInterface $messageManager,
        \PayBy\Payment\Helper\Data $dataHelper
    ) {
        $this->messageManager = $messageManager;
        $this->_dataHelper = $dataHelper;
    }
    /**
     *
     * @param Observer $observer
     * @return void
     */
    public function execute(Observer $observer)
    {

        $this->_dataHelper->log("Order cancel observer start.");
        $order = $observer->getEvent()->getOrder();




        if ($this->_dataHelper->isPaidUsingPayby($order)) {
            $this->_dataHelper->log("Payby order cancel observer start.");
            $order->addStatusHistoryComment(__('Order cancel sent to Payby platform.'), false)
                ->setIsCustomerNotified(false)
                ->save();



            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $storeManager = $objectManager->get('Magento\Store\Model\StoreManagerInterface');
            $storeId = $storeManager->getStore()->getStoreId();

            $partner_id = $this->_dataHelper->getCommonConfigData('partner_id', $storeId);
            $ctx_mode = $this->_dataHelper->getCommonConfigData('ctx_mode', $storeId);
            if ($ctx_mode == 'TEST') {
                \PayBy\Payment\Model\PayBy::$caBundle = __DIR__ . '/../../cert/cacert.pem';
                //$key__sign=__DIR__ . '/../../cert/PayBy_key_private-sign.pem';
                //$key_prod_verify=__DIR__ . '/../../cert/PayBy_key_public_key-verify.pem';
                $key_test_sign = ($this->_dataHelper->getCommonConfigData('key_test_sign', $storeId));
                $key_test_verify = ($this->_dataHelper->getCommonConfigData('key_test_verify', $storeId));
                \PayBy\Payment\Model\PayBy::setPrivateKey($key_test_sign);
                \PayBy\Payment\Model\PayBy::setPublicKey($key_test_verify);
            } else {
                \PayBy\Payment\Model\PayBy::$caBundle = __DIR__ . '/../../cert/cacert.pem';
                $key_prod_sign = ($this->_dataHelper->getCommonConfigData('key_prod_sign', $storeId));
                $key_prod_verify = ($this->_dataHelper->getCommonConfigData('key_prod_verify', $storeId));
                \PayBy\Payment\Model\PayBy::setPrivateKey($key_prod_sign);
                \PayBy\Payment\Model\PayBy::setPublicKey($key_prod_verify);
            }
            \PayBy\Payment\Model\PayBy::setPartnerId($partner_id);





            $merchantOrderNo = $order->getIncrementId();
            $requestTime = time();
            $requestData = [
                'merchantOrderNo' => $merchantOrderNo,

            ];
            try {
                // bizContent

                $this->_dataHelper->log('cancel requestData:' . json_encode($requestData));
                $or = \PayBy\Payment\Model\Api\Order::cancelOrder(
                    $requestData
                );
                if (isset($or->head->code)) {
                    $this->_dataHelper->log('cancel resultData:' . json_encode($or));
                    $code = ($or->head->code);
                    if ($code != 0) {

                        $this->messageManager->addErrorMessage('Order cancel API error:' . $or->head->msg);
                        throw new LocalizedException(
                            __('Order cancel API error:' . $or->head->msg)
                        );
                        //$this->messageManager->addErrorMessage('Order cancel success');

                    }
                }
            } catch (\PayBy\Payment\Model\Error\Base $e) {
                // 捕获报错信息
                $this->messageManager->addErrorMessage($e->getMessage());
                throw new LocalizedException(
                    __('Error API: %1', $e->getMessage())
                );
            }
        }
    }
}
